package com.freespin.casino

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

private val night=Color(0xFF080414)
private val card=Color(0xFF170D2B)
private val pink=Color(0xFFFF39C8)
private val violet=Color(0xFF9D4EDD)
private val gold=Color(0xFFFFD166)
private val aqua=Color(0xFF49E8FF)

private data class Slot(val name:String,val sub:String,val badge:String,val icons:List<String>,val accent:Color,val bet:Int,val prize:Int)
private val slots=listOf(
 Slot("STARLIGHT 777","КОСМИЧЕСКИЙ ДЖЕКПОТ","🌌",listOf("⭐","💎","7️⃣","🌙","👑","☄️","🪐","🔮","✨"),gold,25,1000),
 Slot("FRUIT NEON","ФРУКТОВЫЙ ВЗРЫВ","🍒",listOf("🍒","🍋","🍉","🍇","🍊","🍓","🍍","🥝","💥"),Color(0xFFFF795E),20,700),
 Slot("CYBER GALAXY","ЗА ГРАНЬЮ ВСЕЛЕННОЙ","🚀",listOf("👽","🚀","🪐","☄️","🌌","💫","🛸","🌠","🔷"),aqua,30,1200),
 Slot("GOLD RUSH","ЗОЛОТАЯ ЛИХОРАДКА","👑",listOf("👑","💰","🏆","💎","🗝️","⚱️","🪙","🔱","✨"),gold,35,1500),
 Slot("MAGIC GARDEN","ВОЛШЕБНЫЙ САД","🦄",listOf("🦄","🍀","🧙","🦋","🌈","🌳","🌸","🍄","💜"),Color(0xFF69E6B5),25,900)
)
private data class WinLine(val row:Int,val amount:Int,val symbol:String)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);window.statusBarColor=android.graphics.Color.rgb(8,4,20);window.navigationBarColor=android.graphics.Color.rgb(8,4,20);setContent{SlotCasino()}}
}

@Composable private fun SlotCasino(){
 val context=LocalContext.current
 val prefs= remember{context.getSharedPreferences("casino_v3",0)}
 val tone= remember{ToneGenerator(AudioManager.STREAM_MUSIC,85)}
 DisposableEffect(Unit){onDispose{tone.release()}}
 val scope= rememberCoroutineScope()
 var coins by remember{mutableIntStateOf(prefs.getInt("coins",1500))}
 var tickets by remember{mutableIntStateOf(prefs.getInt("tickets",15))}
 var totalWon by remember{mutableIntStateOf(prefs.getInt("won",0))}
 var selected by remember{mutableIntStateOf(0)}
 var tab by remember{mutableIntStateOf(0)}
 var sound by remember{mutableStateOf(true)}
 var spinning by remember{mutableStateOf(false)}
 var grid by remember{mutableStateOf(List(15){slots[0].icons.random()})}
 var wins by remember{mutableStateOf(emptyList<WinLine>())}
 var message by remember{mutableStateOf("СОБЕРИ КОМБИНАЦИЮ И ПОЛУЧИ МОНЕТЫ")}
 var payout by remember{mutableIntStateOf(0)}
 var showWin by remember{mutableStateOf(false)}
 val game=slots[selected]
 fun persist(){prefs.edit().putInt("coins",coins).putInt("tickets",tickets).putInt("won",totalWon).apply()}
 fun soundSpin(){if(sound){tone.startTone(ToneGenerator.TONE_PROP_BEEP,70)}}
 fun spin(){
  if(spinning)return
  if(tickets<=0&&coins<game.bet){message="НЕ ХВАТАЕТ МОНЕТ — ЗАБЕРИ БОНУС";tone.startTone(ToneGenerator.TONE_PROP_NACK,180);return}
  if(tickets>0)tickets-- else coins-=game.bet
  spinning=true;wins= emptyList();payout=0;showWin=false;persist()
  scope.launch{
   repeat(18){step->
    grid=List(15){game.icons.random()}
    if(sound)tone.startTone(if(step%3==0)ToneGenerator.TONE_PROP_BEEP else ToneGenerator.TONE_PROP_ACK,45)
    delay(65L+step*5L)
   }
   val result=List(15){game.icons.random()}
   // Evaluate five horizontal paylines and two diagonals across the first three reels.
   val lines=mutableListOf<WinLine>()
   for(row in 0..2){
    val a=result[row*5]
    var count=1
    for(col in 1..4){if(result[row*5+col]==a)count++ else break}
    if(count>=3)lines.add(WinLine(row,game.bet*(count-2)*4,a))
   }
   val diag1=(0..4).count{result[it*5+it%3]==result[0]}
   val diag2=(0..4).count{result[it*5+(2-it%3)]==result[2]}
   if(diag1>=3)lines.add(WinLine(3,game.bet*diag1*2,result[0]))
   if(diag2>=3)lines.add(WinLine(4,game.bet*diag2*2,result[2]))
   val total=lines.sumOf{it.amount}
   grid=result;wins=lines;payout=total
   if(total>0){coins+=total;totalWon+=total;message="ЛИНИИ СОВПАДЕНИЙ: ${lines.size}  •  ВЫИГРЫШ +$total";showWin=true
    if(sound){tone.startTone(ToneGenerator.TONE_PROP_ACK,650);delay(180);tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,450)}
   }else{message="НЕТ СОВПАДЕНИЙ — ЕЩЁ ОДИН СПИН?";if(sound)tone.startTone(ToneGenerator.TONE_PROP_NACK,250)}
   spinning=false;persist()
  }
 }
 fun daily(){val day=java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(java.util.Date());if(prefs.getString("daily","")==day)message="БОНУС УЖЕ ПОЛУЧЕН СЕГОДНЯ" else{coins+=500;tickets+=10;prefs.edit().putString("daily",day).apply();message="ЕЖЕДНЕВНЫЙ БОНУС +500 🪙 +10 🎟";persist()}}
 MaterialTheme(colorScheme=darkColorScheme(primary=gold,background=night,surface=card)){
  Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF291044),night,Color(0xFF05020C)))).padding(horizontal=12.dp)){
   Row(Modifier.fillMaxWidth().padding(top=10.dp,bottom=8.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
    Column{Text("✦ FREE SPIN",color=gold,fontSize=24.sp,fontWeight=FontWeight.Black);Text("NEON ARCADE • SLOT CLUB",color=pink,fontSize=9.sp,letterSpacing=2.sp)}
    Column(horizontalAlignment=Alignment.End){Text("🪙 $coins",color=gold,fontWeight=FontWeight.Black,fontSize=17.sp);Text("🎟 $tickets билетов",color=aqua,fontSize=11.sp)}
   }
   Row(Modifier.fillMaxWidth().padding(bottom=8.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){
    listOf("🎰 АВТОМАТЫ","🛍 МАГАЗИН","🎁 БОНУСЫ").forEachIndexed{i,t->Surface(Modifier.weight(1f).clickable{tab=i},shape=RoundedCornerShape(12.dp),color=if(tab==i)violet else card,border=BorderStroke(1.dp,if(tab==i)pink else violet.copy(.35f))){Text(t,Modifier.padding(vertical=12.dp),color=Color.White,fontSize=9.sp,fontWeight=FontWeight.Black,textAlign=TextAlign.Center)}}
   }
   when(tab){
    1->Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
     Title("NEON SHOP","Обменивай виртуальные монеты на билеты")
     listOf(5 to 125,12 to 250,30 to 500).forEach{(count,cost)->Shop(count,cost){if(coins>=cost){coins-=cost;tickets+=count;message="КУПЛЕНО $count БИЛЕТОВ";persist()}else message="НЕДОСТАТОЧНО МОНЕТ"}}
     Text("Только игровые монеты. Покупки за реальные деньги и вывод средств отсутствуют.",color=Color.LightGray,fontSize=10.sp)
    }
    2->Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(14.dp)){
     Title("DAILY BONUS","Возвращайся каждый день за наградой")
     NeonButton("ЗАБРАТЬ +500 МОНЕТ И +10 БИЛЕТОВ",gold){daily()}
     Surface(color=card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,violet)){Column(Modifier.padding(18.dp)){Text("🏆 ТВОЯ СТАТИСТИКА",color=gold,fontWeight=FontWeight.Black);Text("Всего выиграно: $totalWon монет",color=Color.White);Text("Баланс билетов: $tickets",color=aqua)}}
    }
    else->Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)){
     Text("ВЫБЕРИ СВОЙ АВТОМАТ",color=gold,fontWeight=FontWeight.Black,fontSize=13.sp)
     LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=3.dp)){
      itemsIndexed(slots){i,s->Surface(Modifier.width(145.dp).clickable(enabled=!spinning){selected=i;grid=List(15){s.icons.random()};wins= emptyList();message="ТЫ ВЫБРАЛ ${s.name}"},shape=RoundedCornerShape(14.dp),color=if(selected==i)s.accent.copy(.22f)else card,border=BorderStroke(if(selected==i)2.dp else 1.dp,if(selected==i)s.accent else violet.copy(.35f))){Column(Modifier.padding(10.dp)){Text(s.badge,fontSize=23.sp);Text(s.name,color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Black);Text("СТАВКА ${s.bet} 🪙",color=s.accent,fontSize=9.sp)}}
      }
     }
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text(game.name,color=game.accent,fontWeight=FontWeight.Black,fontSize=18.sp);Text(game.sub,color=Color.LightGray,fontSize=9.sp)};Text("5 × 3 • 15 СИМВОЛОВ",color=aqua,fontSize=9.sp,fontWeight=FontWeight.Bold)}
     // Cabinet with a 5-column x 3-row reel window.
     Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.verticalGradient(listOf(Color(0xFF4A1D68),Color(0xFF170B2D),Color(0xFF080411)))).border(3.dp,Brush.linearGradient(listOf(gold,pink,violet,gold)),RoundedCornerShape(22.dp)).padding(9.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
      Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center){Text("✦  ${game.badge}  ✦",color=gold,fontSize=13.sp,fontWeight=FontWeight.Black)}
      Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color(0xFF05020D)).border(2.dp,game.accent,RoundedCornerShape(13.dp)).padding(5.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
       for(row in 0..2){Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){
        for(col in 0..4){
         val index=row*5+col
         val active=wins.any{it.row==row}
         val infinite= rememberInfiniteTransition(label="cell$index")
         val glow by infinite.animateFloat(.75f,1f,infiniteRepeatable(tween(450),RepeatMode.Reverse),label="glow")
         Box(Modifier.weight(1f).aspectRatio(1f).scale(if(active&&!spinning)glow else 1f).clip(RoundedCornerShape(7.dp)).background(Brush.verticalGradient(listOf(Color(0xFFFFF9E9),Color(0xFFFFD987),Color(0xFFE9A94C)))).border(if(active)2.dp else 1.dp,if(active)pink else Color.White.copy(.3f),RoundedCornerShape(7.dp)),contentAlignment=Alignment.Center){Text(grid[index],fontSize=if(col==4)22.sp else 23.sp)}
        }
       }}
      }
      Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("PAYLINES: 5",color=aqua,fontSize=9.sp,fontWeight=FontWeight.Bold);Text("3+ В РЯДУ = ВЫИГРЫШ",color=gold,fontSize=9.sp,fontWeight=FontWeight.Bold)}
      AnimatedVisibility(showWin){Text("✨  WIN +$payout МОНЕТ  ✨",Modifier.fillMaxWidth().background(Color(0xFF3A164B),RoundedCornerShape(10.dp)).padding(8.dp),color=gold,fontSize=17.sp,fontWeight=FontWeight.Black,textAlign=TextAlign.Center)}
      Text(message,Modifier.fillMaxWidth(),color=if(showWin)gold else Color.White,fontSize=10.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center,minLines=2)
      NeonButton(if(spinning)"БАРАБАНЫ ВРАЩАЮТСЯ..." else "КРУТИТЬ  •  ${game.bet} 🪙  /  1 🎟",pink){spin()}
      Text("3 одинаковых символа на линии: ${game.bet*4} монет • 4: ${game.bet*8} • 5: ${game.bet*12}",color=Color.LightGray,fontSize=9.sp,textAlign=TextAlign.Center)
     }
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){Text("🔊 ЗВУК",color=Color.LightGray,fontSize=10.sp);Switch(sound,{sound=it});Spacer(Modifier.weight(1f));Text("🏆 ВЫИГРАНО $totalWon",color=gold,fontSize=10.sp,fontWeight=FontWeight.Bold)}
    }
   }
   Text("ARCADE DEMO • ВИРТУАЛЬНЫЕ МОНЕТЫ • НЕ ДЕНЬГИ",Modifier.fillMaxWidth().padding(vertical=7.dp),color=Color(0xFF857A99),fontSize=8.sp,textAlign=TextAlign.Center)
  }
 }
}
@Composable private fun Title(a:String,b:String){Column{Text(a,color=gold,fontSize=21.sp,fontWeight=FontWeight.Black);Text(b,color=Color.LightGray,fontSize=11.sp)}}
@Composable private fun Shop(n:Int,cost:Int,buy:()->Unit){Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(card).border(1.dp,violet,RoundedCornerShape(16.dp)).padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text("🎟",fontSize=28.sp);Column(Modifier.weight(1f).padding(start=12.dp)){Text("$n БИЛЕТОВ",color=Color.White,fontWeight=FontWeight.Black);Text("$cost 🪙",color=gold)};Button(onClick=buy,colors=ButtonDefaults.buttonColors(containerColor=pink,contentColor=night)){Text("ОБМЕН",fontWeight=FontWeight.Black)} }}
@Composable private fun NeonButton(text:String,color:Color,onClick:()->Unit){Button(onClick=onClick,modifier=Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=color,contentColor=night)){Text(text,fontWeight=FontWeight.Black,fontSize=11.sp,textAlign=TextAlign.Center)}}
