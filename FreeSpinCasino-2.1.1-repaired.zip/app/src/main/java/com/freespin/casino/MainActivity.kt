package com.freespin.casino

import android.os.Bundle
import androidx.compose.ui.platform.LocalConfiguration
import android.os.Vibrator
import android.os.VibrationEffect
import android.app.DatePickerDialog
import android.media.AudioManager
import android.media.ToneGenerator
import android.graphics.BitmapFactory
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.layout.ContentScale
import java.util.Calendar
import org.json.JSONArray
import org.json.JSONObject

private data class Machine(val name:String,val icon:String,val symbols:List<String>,val bg:Long,val accent:Long)
private val machines=listOf(
 Machine("STARLIGHT 777","🌌",listOf("⭐","🪐","💎","☄️","🌙","🔮"),0xFF24134D,0xFFD8B5FF),
 Machine("FRUIT NEON","🍒",listOf("🍒","🍋","🍉","🍇","🍊","🍓"),0xFF50142F,0xFFFF89B5),
 Machine("CYBER SPIN","🤖",listOf("🤖","⚡","💾","🚀","🔋","💠"),0xFF073641,0xFF55F5FF),
 Machine("GOLDEN EGYPT","🏺",listOf("🏺","🐈","☀️","💎","🪲","👑"),0xFF493014,0xFFFFDA78),
 Machine("PIRATE GOLD","🏴‍☠️",listOf("⚓","🦜","💰","💎","🗝️","🏴‍☠️"),0xFF153B39,0xFF8BE1C6),
 Machine("DRAGON FIRE","🐉",listOf("🐉","🔥","🥚","💎","🏯","☄️"),0xFF511C13,0xFFFFAB68))
private data class Match(val cells:List<Int>,val direction:Int)
private fun matches(grid:List<String>):List<Match>{
 val out=mutableListOf<Match>()
 val dirs=listOf(0 to 1,1 to 0,1 to 1,1 to -1)
 fun inside(r:Int,c:Int)=r in 0..3 && c in 0..4
 for((d,p) in dirs.withIndex()) for(r in 0..3) for(c in 0..4){
  val (dr,dc)=p; val s=grid[r*5+c]; val pr=r-dr;val pc=c-dc
  if(inside(pr,pc)&&grid[pr*5+pc]==s)continue
  val cells=mutableListOf<Int>();var y=r;var x=c
  while(inside(y,x)&&grid[y*5+x]==s){cells.add(y*5+x);y+=dr;x+=dc}
  if(cells.size>=3)out.add(Match(cells,d))
 };return out
}
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{Arcade()}}}
@Composable private fun Arcade(){
 val ctx=LocalContext.current;val wide=LocalConfiguration.current.screenWidthDp>LocalConfiguration.current.screenHeightDp;val prefs=remember{ctx.getSharedPreferences("casino_v3",0)};val scope=rememberCoroutineScope()
 var screen by remember{mutableStateOf("splash")};var name by remember{mutableStateOf(prefs.getString("name","Игрок")?:"Игрок")};var birth by remember{mutableStateOf(prefs.getString("birth","")?:"")}
 var coins by remember{mutableIntStateOf(prefs.getInt("coins",1500))};var tickets by remember{mutableIntStateOf(prefs.getInt("tickets",15))};var sound by remember{mutableStateOf(prefs.getBoolean("sound",true))};var volume by remember{mutableFloatStateOf(prefs.getFloat("volume",0.8f))};var anim by remember{mutableStateOf(prefs.getBoolean("anim",true))}
 var photo by remember{mutableStateOf(prefs.getString("photo","")?:"")};var history by remember{mutableStateOf(prefs.getString("history","[]")?:"[]")};var won by remember{mutableIntStateOf(prefs.getInt("winCount",0))};var lost by remember{mutableIntStateOf(prefs.getInt("lossCount",0))};var biggest by remember{mutableIntStateOf(prefs.getInt("biggest",0))}
 var draft by remember { mutableStateOf(name) }; var profileStatus by remember { mutableStateOf("") }; var saving by remember { mutableStateOf(false) }; var draftPhoto by remember { mutableStateOf(photo) }; val reelOffsets = remember { List(5) { Animatable(0f) } }; var reelStrips by remember { mutableStateOf(List(5){ emptyList<String>() }) }; val cellPx = with(LocalDensity.current){ 64.dp.toPx() }
 var dice by remember{mutableStateOf(listOf(1,1))};var roulette by remember{mutableIntStateOf(0)};val wheelAngle=remember{Animatable(0f)};var music by remember{mutableStateOf(prefs.getBoolean("music",true))};var musicVolume by remember{mutableFloatStateOf(prefs.getFloat("musicVolume",0.4f))};var vibration by remember{mutableStateOf(prefs.getBoolean("vibration",true))};var selected by remember{mutableIntStateOf(0)};val game=machines[selected];var bet by remember{mutableIntStateOf(25)};var grid by remember{mutableStateOf(List(20){machines[0].symbols.random()})};var lines by remember{mutableStateOf(emptyList<Match>())};var busy by remember{mutableStateOf(false)};var msg by remember{mutableStateOf("")}
 val tone=remember(volume){runCatching{ToneGenerator(AudioManager.STREAM_MUSIC,(volume*100).toInt())}.getOrNull()};DisposableEffect(tone){onDispose{tone?.release()}}
 fun play(t:Int,ms:Int=100){if(sound)tone?.startTone(t,ms);if(vibration)runCatching{val v=ctx.getSystemService(android.content.Context.VIBRATOR_SERVICE) as Vibrator;if(android.os.Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(35,VibrationEffect.DEFAULT_AMPLITUDE)) else v.vibrate(35)}}
 val player=remember(screen,selected,music){if(music&&screen in listOf("home","game","roulette","dice"))runCatching{val id=ctx.resources.getIdentifier("theme_"+(if(screen=="game")selected+1 else if(screen=="roulette")7 else if(screen=="dice")8 else 0),"raw",ctx.packageName);android.media.MediaPlayer.create(ctx,id)?.apply{isLooping=true;setVolume(musicVolume,musicVolume);start()}}.getOrNull() else null};DisposableEffect(player){onDispose{player?.release()}};LaunchedEffect(player,musicVolume){player?.setVolume(musicVolume,musicVolume)}
 fun save(){prefs.edit().putBoolean("music",music).putFloat("musicVolume",musicVolume).putBoolean("vibration",vibration).putString("name",name).putString("birth",birth).putString("photo",photo).putInt("coins",coins).putInt("tickets",tickets).putBoolean("sound",sound).putFloat("volume",volume).putBoolean("anim",anim).putString("history",history).putInt("winCount",won).putInt("lossCount",lost).putInt("biggest",biggest).apply()}
 fun adult(date:String):Boolean=runCatching{val p=date.split("-").map{it.toInt()};val b=Calendar.getInstance().apply{clear();isLenient=false;set(p[0],p[1]-1,p[2])};val limit=Calendar.getInstance().apply{add(Calendar.YEAR,-18)};b.timeInMillis<=limit.timeInMillis && p[0]>=1900}.getOrDefault(false)
 fun datePick(){val now=Calendar.getInstance();DatePickerDialog(ctx,{_,y,m,d->birth="%04d-%02d-%02d".format(java.util.Locale.US,y,m+1,d);save();if(!adult(birth))screen="age"},now.get(Calendar.YEAR)-18,now.get(Calendar.MONTH),now.get(Calendar.DAY_OF_MONTH)).apply{datePicker.maxDate=now.timeInMillis}.show()}
 val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null){runCatching{ctx.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);draftPhoto=uri.toString()}}}
 fun go(s:String){if(!busy&&!saving){play(ToneGenerator.TONE_PROP_BEEP,60);if(s=="profile"){draft=name;draftPhoto=photo;profileStatus=""};screen=s;msg=""}}
 LaunchedEffect(Unit){delay(if(anim)1600 else 200);screen=if(adult(birth))"home" else "age"}
 BackHandler(screen!="home"&&screen!="age"&&screen!="splash"){go("home")}
 fun spin(ticket:Boolean){if(busy)return;if((ticket&&tickets<=0)||(!ticket&&coins<bet)){msg="Недостаточно средств";return};busy=true;lines=emptyList();val stake=bet
 scope.launch{val result=List(20){game.symbols.random()};if(anim){reelStrips=List(5){c->List(4){r->grid[r*5+c]}+List(16){game.symbols.random()}+List(4){r->result[r*5+c]}};kotlinx.coroutines.coroutineScope { for(c in 0..4) launch { reelOffsets[c].snapTo(0f);reelOffsets[c].animateTo(20f*cellPx,tween(950+c*180,easing=LinearOutSlowInEasing)) } }};grid=result;play(ToneGenerator.TONE_PROP_ACK,100);lines=matches(grid);val payout=lines.sumOf{stake*(it.cells.size-2)*4};if(ticket)tickets-- else coins-=stake;coins+=payout;val net=payout-(if(ticket)0 else stake);if(payout>0){won++;biggest=maxOf(biggest,payout);play(if(payout>=stake*12)ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD else ToneGenerator.TONE_PROP_ACK,450)}else{lost++;play(ToneGenerator.TONE_PROP_NACK,220)};msg=if(payout>0)"Совпадений: ${lines.size} • +$payout монет" else "Нет совпадений";val old=JSONArray(history);val arr=JSONArray().put(JSONObject().put("game",game.name).put("time",System.currentTimeMillis()).put("bet",stake).put("ticket",ticket).put("payout",payout).put("net",net));for(i in 0 until minOf(old.length(),499))arr.put(old.getJSONObject(i));history=arr.toString();save();busy=false}}
 fun recordExtra(label:String,stake:Int,payout:Int){coins+=payout;if(payout>0){won++;biggest=maxOf(biggest,payout)}else lost++;val old=JSONArray(history);val arr=JSONArray().put(JSONObject().put("game",label).put("time",System.currentTimeMillis()).put("bet",stake).put("payout",payout).put("net",payout-stake));for(i in 0 until minOf(old.length(),499))arr.put(old.getJSONObject(i));history=arr.toString();save()}
 val accent=if(screen=="game")Color(game.accent)else Color(0xFFFFDA78);val bg=if(screen=="game")Color(game.bg)else Color(0xFF190D2B)
 MaterialTheme(colorScheme=darkColorScheme(primary=accent,background=bg,surface=bg,onBackground=Color.White,onSurface=Color.White,onSurfaceVariant=Color.LightGray)){
 CompositionLocalProvider(LocalContentColor provides Color.White) {
 Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bg,Color(0xFF080414)))).systemBarsPadding().verticalScroll(rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 if(screen=="splash"){val transition=rememberInfiniteTransition(label="splash");val scale by transition.animateFloat(.8f,1.1f,infiniteRepeatable(tween(500),RepeatMode.Reverse),label="logo");Box(Modifier.fillMaxWidth().height(450.dp),contentAlignment=Alignment.Center){Text("✦ FREE SPIN ✦\n3.1.0 ARCADE",Modifier.scale(if(anim)scale else 1f),color=accent,fontSize=32.sp,fontWeight=FontWeight.Black)}}else if(screen=="age"){
 Text("FREE SPIN • 18+",fontSize=30.sp,color=accent);Text("Введите дату рождения. Только для взрослых. Дата вводится самостоятельно.");Button(onClick={datePick()}){Text(birth.ifEmpty{"Выбрать дату рождения"})};if(birth.isNotEmpty()&&!adult(birth))Text("Доступ только с 18 лет",color=Color.Red);Button(onClick={save();go("home")},enabled=adult(birth)){Text("Продолжить")}
 }else{
 Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){if(screen=="home")TextButton(onClick={go("profile")}){Row(verticalAlignment=Alignment.CenterVertically){ProfileAvatar(photo,32.dp);Spacer(Modifier.width(5.dp));Text(name.take(16))}}else TextButton(onClick={go("home")},enabled=!busy){Text("‹ Назад")};Text("🪙 $coins  🎟 $tickets",color=accent);if(screen=="home")TextButton(onClick={go("settings")}){Text("⚙")}}
 when(screen){
 "home"->{Text("FREE SPIN • 3.1.0",fontSize=28.sp,fontWeight=FontWeight.Black,color=accent);Text("Выбери автомат");for(pair in machines.chunked(if(wide)3 else 2)){Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){for(m in pair){Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(Color(m.bg)).border(1.dp,Color(m.accent),RoundedCornerShape(18.dp)).clickable{selected=machines.indexOf(m);grid=List(20){m.symbols.random()};lines=emptyList();go("game")}.padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(m.icon,fontSize=40.sp);Text(m.name,color=Color(m.accent),fontWeight=FontWeight.Bold);Text("ИГРАТЬ")}}}};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){Button(onClick={go("roulette")}){Text("Рулетка")};Button(onClick={go("dice")}){Text("Кости")}};Row{TextButton(onClick={go("shop")}){Text("🛍 Магазин")};TextButton(onClick={go("bonus")}){Text("🎁 Бонусы")}}}
 "game"->{Text(game.icon+" "+game.name,color=accent,fontSize=25.sp,fontWeight=FontWeight.Black);Box(Modifier.fillMaxWidth().height(256.dp).background(bg,RoundedCornerShape(12.dp))){Row(Modifier.fillMaxSize(),horizontalArrangement=Arrangement.spacedBy(4.dp)){for(c in 0..4){Box(Modifier.weight(1f).fillMaxHeight().clipToBounds().border(1.dp,accent,RoundedCornerShape(8.dp))){Column(Modifier.offset { androidx.compose.ui.unit.IntOffset(0,if(busy&&anim&&reelStrips[c].isNotEmpty()) -reelOffsets[c].value.toInt() else 0) }.wrapContentHeight(Alignment.Top,unbounded=true)){val symbols=if(busy&&anim&&reelStrips[c].isNotEmpty())reelStrips[c] else List(4){r->grid[r*5+c]};for((r,symbol) in symbols.withIndex()){Box(Modifier.fillMaxWidth().height(64.dp).padding(2.dp).background(Brush.verticalGradient(listOf(Color(0xFF171321),accent.copy(alpha=if(!busy&&lines.any{r*5+c in it.cells}) .8f else .35f),Color(0xFF171321))),RoundedCornerShape(8.dp)),contentAlignment=Alignment.Center){Text(symbol,fontSize=27.sp)}}}}}};Canvas(Modifier.matchParentSize()){for(l in lines){val a=l.cells.first();val b=l.cells.last();val w=size.width/5;val h=size.height/4;drawLine(listOf(Color.Yellow,Color.Cyan,Color.Magenta,Color.Green)[l.direction],Offset((a%5+.5f)*w,(a/5+.5f)*h),Offset((b%5+.5f)*w,(b/5+.5f)*h),strokeWidth=4.dp.toPx())}}};Text("3+ одинаковых подряд • все направления • пересечения оплачиваются отдельно");Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){Button(onClick={bet=(bet-5).coerceAtLeast(5)},enabled=!busy){Text("−")};Text("Ставка $bet",color=accent,fontSize=20.sp);Button(onClick={bet=(bet+5).coerceAtMost(100)},enabled=!busy){Text("+")}};Button(onClick={spin(false)},enabled=!busy&&coins>=bet,modifier=Modifier.fillMaxWidth()){Text(if(busy)"Вращение…" else "КРУТИТЬ • $bet 🪙")};OutlinedButton(onClick={spin(true)},enabled=!busy&&tickets>0,modifier=Modifier.fillMaxWidth()){Text("Вращение за билет")};Text(msg,color=accent)}
 "roulette"->{Text("ЕВРОПЕЙСКАЯ РУЛЕТКА",fontSize=24.sp,color=accent);Box(Modifier.fillMaxWidth(),contentAlignment=Alignment.Center){Canvas(Modifier.size(if(wide)220.dp else 300.dp).rotate(wheelAngle.value)){val colors=listOf(Color(0xFFAA2020),Color(0xFF171717));for(i in 0..36){drawArc(if(i==0)Color(0xFF168044) else colors[i%2],i*360f/37f,360f/37f-0.4f,true)};drawCircle(Color(0xFFCC9C48),size.minDimension*.23f);drawCircle(Color(0xFF322015),size.minDimension*.19f)};Text(roulette.toString(),fontSize=36.sp,color=Color.White)};Text("Результат: $roulette");Button(enabled=!busy,onClick={busy=true;scope.launch{val n=(0..36).random();if(anim)wheelAngle.animateTo(wheelAngle.value+1080f+n*360f/37f,tween(1800,easing=LinearOutSlowInEasing));roulette=n;busy=false;play(ToneGenerator.TONE_PROP_ACK)}}){Text("Вращать колесо")};Text("Свободная игра без ставок")}
 "dice"->{Text("ИГРОВЫЕ КОСТИ",fontSize=24.sp,color=accent);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center){for(n in dice){Box(Modifier.padding(8.dp).size(100.dp).background(Color.White,RoundedCornerShape(16.dp)),contentAlignment=Alignment.Center){Text(listOf("⚀","⚁","⚂","⚃","⚄","⚅")[n-1],fontSize=76.sp,color=Color.Black)}}};Text("Сумма: ${dice.sum()}",fontSize=24.sp);Button(enabled=!busy,onClick={busy=true;scope.launch{if(anim)repeat(12){dice=List(2){(1..6).random()};delay(65)};dice=List(2){(1..6).random()};play(ToneGenerator.TONE_PROP_ACK);busy=false}}){Text("Бросить кости")};Text("Свободная игра без ставок")}
 "profile"->{Text("МОЙ АККАУНТ",fontSize=24.sp,color=accent);ProfileAvatar(draftPhoto,100.dp);Button(onClick={picker.launch(arrayOf("image/*"))},enabled=!saving){Text("Выбрать фото")};OutlinedTextField(draft,{draft=it.take(24);profileStatus=""},label={Text("Имя")},enabled=!saving);Text("3–24 латинские буквы, цифры или _");Button(enabled=!saving,onClick={val candidate=draft.trim().lowercase(java.util.Locale.ROOT);if(!candidate.matches(Regex("^[a-z0-9_]{3,24}$"))){profileStatus="Недопустимое имя"}else{saving=true;scope.launch{try{val auth=FirebaseAuth.getInstance();val uid=(auth.currentUser?:auth.signInAnonymously().await().user?:error("auth")).uid;val db=FirebaseFirestore.getInstance();val ref=db.collection("usernames").document(candidate);val old=prefs.getString("reservedName","").orEmpty();val ok=db.runTransaction{tx->val doc=tx.get(ref);if(doc.exists()&&doc.getString("uid")!=uid)false else {val previous=if(old.isNotEmpty()&&old!=candidate)db.collection("usernames").document(old) else null;val previousDoc=previous?.let{tx.get(it)};if(!doc.exists())tx.set(ref,mapOf("uid" to uid));if(previous!=null&&previousDoc?.getString("uid")==uid)tx.delete(previous);true}}.await();if(ok){name=draft.trim();photo=draftPhoto;prefs.edit().putString("reservedName",candidate).apply();save();profileStatus="Сохранено"}else profileStatus="Имя уже занято"}catch(e:Exception){profileStatus="Не удалось проверить имя. Проверьте интернет."}finally{saving=false}}}}){Text(if(saving)"Проверка…" else "Сохранить")};Text(profileStatus);Button(onClick={datePick()}){Text("Дата рождения: $birth")};Text("Выигрышей: $won • проигрышей: $lost");Text("Всего: ${won+lost} • крупнейший выигрыш: $biggest");Text("История игр",fontSize=22.sp);val arr=JSONArray(history);for(i in 0 until arr.length()){val h=arr.getJSONObject(i);Text(h.getString("game")+" • "+java.text.DateFormat.getDateTimeInstance().format(java.util.Date(h.getLong("time")))+"\nСтавка: "+h.getInt("bet")+ (if(h.optBoolean("ticket"))" (билет)" else " монет")+" • Выплата: "+h.getInt("payout")+" • Итог: "+h.getInt("net"));HorizontalDivider()}}
 "settings"->{Text("НАСТРОЙКИ",fontSize=24.sp,color=accent);Row(verticalAlignment=Alignment.CenterVertically){Text("Звуковые эффекты",Modifier.weight(1f));Switch(sound,{sound=it;save()})};Text("Громкость ${(volume*100).toInt()}%");Slider(volume,{volume=it;save()});Row(verticalAlignment=Alignment.CenterVertically){Text("Анимации",Modifier.weight(1f));Switch(anim,{anim=it;save()})};Row(verticalAlignment=Alignment.CenterVertically){Text("Музыка",Modifier.weight(1f));Switch(music,{music=it})};Text("Громкость музыки ${(musicVolume*100).toInt()}%");Slider(musicVolume,{musicVolume=it});Row(verticalAlignment=Alignment.CenterVertically){Text("Вибрация",Modifier.weight(1f));Switch(vibration,{vibration=it})};Button(onClick={save();msg="Настройки сохранены"}){Text("Сохранить")};Text(msg);Button(onClick={ctx.startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://github.com/GRESHNYY-ZM/FreeSpinCasino/releases")))}){Text("Проверить обновления")};Text("Русский • 3.1.0 Arcade\nДанные хранятся на устройстве. Реальные деньги не используются.")}
 "shop"->{Text("Магазин виртуальных билетов",fontSize=22.sp);for((n,c) in listOf(5 to 125,12 to 250,30 to 500)){Button(onClick={coins-=c;tickets+=n;save()},enabled=coins>=c){Text("$n билетов за $c монет")}}}
 "bonus"->{Text("Ежедневный бонус",fontSize=24.sp);for((i,reward) in listOf("100 монет","200 монет","2 билета","400 монет","600 монет","5 билетов","1000 монет + 10 билетов").withIndex()){Text("День ${i+1}: $reward")};val day=java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(java.util.Date());var claimed by remember{mutableStateOf(prefs.getString("daily","")==day)};Button(onClick={val index=prefs.getInt("rewardIndex",0)%7;coins+=listOf(100,200,0,400,600,0,1000)[index];tickets+=listOf(0,0,2,0,0,5,10)[index];claimed=true;prefs.edit().putString("daily",day).putInt("rewardIndex",index+1).apply();save()},enabled=!claimed){Text(if(claimed)"Получено сегодня" else "Получить награду дня ${prefs.getInt("rewardIndex",0)%7+1}")}}
 };Text("18+ • Только виртуальные монеты • Без денежных ставок",color=Color.LightGray,fontSize=11.sp)
 }
 }}
}
}

@Composable private fun ProfileAvatar(photo:String,size:Dp){val ctx=LocalContext.current;val bitmap=remember(photo){if(photo.isBlank())null else runCatching{ctx.contentResolver.openInputStream(android.net.Uri.parse(photo))?.use{BitmapFactory.decodeStream(it)}}.getOrNull()};if(bitmap!=null)Image(bitmap.asImageBitmap(),"Фото профиля",Modifier.size(size).clip(RoundedCornerShape(50)),contentScale=ContentScale.Crop)else Text("👤",fontSize=(size.value*.6f).sp)}
