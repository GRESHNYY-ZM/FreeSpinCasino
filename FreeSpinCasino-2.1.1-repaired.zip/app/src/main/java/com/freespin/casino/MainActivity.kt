package com.freespin.casino

import android.os.Bundle
import android.app.DatePickerDialog
import android.media.AudioManager
import android.media.ToneGenerator
import android.graphics.BitmapFactory
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import org.json.JSONArray
import org.json.JSONObject

private data class Machine(val name:String,val icon:String,val symbols:List<String>,val bg:Long,val accent:Long)
private val machines=listOf(
 Machine("STARLIGHT 777","🌌",listOf("⭐","🪐","💎","☄️","🌙","🔮"),0xFF24134D,0xFFD8B5FF),
 Machine("FRUIT NEON","🍒",listOf("🍒","🍋","🍉","🍇","🍊","🍓"),0xFF50142F,0xFFFF89B5),
 Machine("CYBER SPIN","🤖",listOf("🤖","⚡","💾","🚀","🔋","💠"),0xFF073641,0xFF55F5FF),
 Machine("GOLDEN EGYPT","🏺",listOf("🏺","🐈","☀️","💎","🪲","👑"),0xFF493014,0xFFFFDA78),
 Machine("PIRATE GOLD","🏴‍☠️",listOf("⚓","🦜","💰","💎","🗝️","🏴‍☠️"),0xFF153B39,0xFF8BE1C6),
 Machine("DRAGON FIRE","🐉",listOf("🐉","🔥","🥚","💎","🏯","☄️"),0xFF511C13,0xFFFFAB68))
private data class Match(val cells:List<Int>,val direction:Int)
private fun matches(grid:List<String>):List<Match>{
 val out=mutableListOf<Match>()
 val dirs=listOf(0 to 1,1 to 0,1 to 1,1 to -1)
 fun inside(r:Int,c:Int)=r in 0..3 && c in 0..4
 for((d,p) in dirs.withIndex()) for(r in 0..3) for(c in 0..4){
  val (dr,dc)=p; val s=grid[r*5+c]; val pr=r-dr;val pc=c-dc
  if(inside(pr,pc)&&grid[pr*5+pc]==s)continue
  val cells=mutableListOf<Int>();var y=r;var x=c
  while(inside(y,x)&&grid[y*5+x]==s){cells.add(y*5+x);y+=dr;x+=dc}
  if(cells.size>=3)out.add(Match(cells,d))
 };return out
}
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{Arcade()}}}
@Composable private fun Arcade(){
 val ctx=LocalContext.current;val prefs=remember{ctx.getSharedPreferences("casino_v3",0)};val scope=rememberCoroutineScope()
 var screen by remember{mutableStateOf("splash")};var name by remember{mutableStateOf(prefs.getString("name","Игрок")?:"Игрок")};var birth by remember{mutableStateOf(prefs.getString("birth","")?:"")}
 var coins by remember{mutableIntStateOf(prefs.getInt("coins",1500))};var tickets by remember{mutableIntStateOf(prefs.getInt("tickets",15))};var sound by remember{mutableStateOf(prefs.getBoolean("sound",true))};var volume by remember{mutableFloatStateOf(prefs.getFloat("volume",0.8f))};var anim by remember{mutableStateOf(prefs.getBoolean("anim",true))}
 var photo by remember{mutableStateOf(prefs.getString("photo","")?:"")};var history by remember{mutableStateOf(prefs.getString("history","[]")?:"[]")};var won by remember{mutableIntStateOf(prefs.getInt("winCount",0))};var lost by remember{mutableIntStateOf(prefs.getInt("lossCount",0))};var biggest by remember{mutableIntStateOf(prefs.getInt("biggest",0))}
 var selected by remember{mutableIntStateOf(0)};val game=machines[selected];var bet by remember{mutableIntStateOf(25)};var grid by remember{mutableStateOf(List(20){machines[0].symbols.random()})};var lines by remember{mutableStateOf(emptyList<Match>())};var busy by remember{mutableStateOf(false)};var msg by remember{mutableStateOf("")}
 val tone=remember(volume){runCatching{ToneGenerator(AudioManager.STREAM_MUSIC,(volume*100).toInt())}.getOrNull()};DisposableEffect(tone){onDispose{tone?.release()}}
 fun play(t:Int,ms:Int=100){if(sound)tone?.startTone(t,ms)}
 fun save(){prefs.edit().putString("name",name).putString("birth",birth).putString("photo",photo).putInt("coins",coins).putInt("tickets",tickets).putBoolean("sound",sound).putFloat("volume",volume).putBoolean("anim",anim).putString("history",history).putInt("winCount",won).putInt("lossCount",lost).putInt("biggest",biggest).apply()}
 fun adult(date:String):Boolean=runCatching{val p=date.split("-").map{it.toInt()};val b=Calendar.getInstance().apply{clear();isLenient=false;set(p[0],p[1]-1,p[2])};val limit=Calendar.getInstance().apply{add(Calendar.YEAR,-18)};b.timeInMillis<=limit.timeInMillis && p[0]>=1900}.getOrDefault(false)
 fun datePick(){val now=Calendar.getInstance();DatePickerDialog(ctx,{_,y,m,d->birth="%04d-%02d-%02d".format(java.util.Locale.US,y,m+1,d);save();if(!adult(birth))screen="age"},now.get(Calendar.YEAR)-18,now.get(Calendar.MONTH),now.get(Calendar.DAY_OF_MONTH)).apply{datePicker.maxDate=now.timeInMillis}.show()}
 val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null){runCatching{ctx.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);photo=uri.toString();save()}}}
 fun go(s:String){if(!busy){play(ToneGenerator.TONE_PROP_BEEP,60);screen=s;msg=""}}
 LaunchedEffect(Unit){delay(if(anim)1600 else 200);screen=if(adult(birth))"home" else "age"}
 BackHandler(screen!="home"&&screen!="age"&&screen!="splash"){go("home")}
 fun spin(ticket:Boolean){if(busy)return;if((ticket&&tickets<=0)||(!ticket&&coins<bet)){msg="Недостаточно средств";return};busy=true;lines=emptyList();val stake=bet
 scope.launch{repeat(if(anim)15 else 1){grid=List(20){game.symbols.random()};play(ToneGenerator.TONE_PROP_BEEP,45);delay(65L+it*8)};play(ToneGenerator.TONE_PROP_ACK,100);lines=matches(grid);val payout=lines.sumOf{stake*(it.cells.size-2)*4};if(ticket)tickets-- else coins-=stake;coins+=payout;val net=payout-(if(ticket)0 else stake);if(payout>0){won++;biggest=maxOf(biggest,payout);play(if(payout>=stake*12)ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD else ToneGenerator.TONE_PROP_ACK,450)}else{lost++;play(ToneGenerator.TONE_PROP_NACK,220)};msg=if(payout>0)"Совпадений: ${lines.size} • +$payout монет" else "Нет совпадений";val old=JSONArray(history);val arr=JSONArray().put(JSONObject().put("game",game.name).put("time",System.currentTimeMillis()).put("bet",stake).put("ticket",ticket).put("payout",payout).put("net",net));for(i in 0 until minOf(old.length(),499))arr.put(old.getJSONObject(i));history=arr.toString();save();busy=false}}
 val accent=if(screen=="game")Color(game.accent)else Color(0xFFFFDA78);val bg=if(screen=="game")Color(game.bg)else Color(0xFF190D2B)
 MaterialTheme(colorScheme=darkColorScheme(primary=accent,background=bg,surface=bg)){
 Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bg,Color(0xFF080414)))).systemBarsPadding().verticalScroll(rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 if(screen=="splash"){val transition=rememberInfiniteTransition(label="splash");val scale by transition.animateFloat(.8f,1.1f,infiniteRepeatable(tween(500),RepeatMode.Reverse),label="logo");Box(Modifier.fillMaxWidth().height(450.dp),contentAlignment=Alignment.Center){Text("✦ FREE SPIN ✦\n3.0 ARCADE",Modifier.scale(if(anim)scale else 1f),color=accent,fontSize=32.sp,fontWeight=FontWeight.Black)}}else if(screen=="age"){
 Text("FREE SPIN • 18+",fontSize=30.sp,color=accent);Text("Введите дату рождения. Только для взрослых. Дата вводится самостоятельно.");Button(onClick={datePick()}){Text(birth.ifEmpty{"Выбрать дату рождения"})};if(birth.isNotEmpty()&&!adult(birth))Text("Доступ только с 18 лет",color=Color.Red);Button(onClick={save();go("home")},enabled=adult(birth)){Text("Продолжить")}
 }else{
 Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){if(screen=="home")TextButton(onClick={go("profile")}){Text("👤 Аккаунт")}else TextButton(onClick={go("home")},enabled=!busy){Text("‹ Назад")};Text("🪙 $coins  🎟 $tickets",color=accent);if(screen=="home")TextButton(onClick={go("settings")}){Text("⚙")}}
 when(screen){
 "home"->{Text("FREE SPIN • 3.0",fontSize=28.sp,fontWeight=FontWeight.Black,color=accent);Text("Выбери автомат");for(pair in machines.chunked(2)){Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){for(m in pair){Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(Color(m.bg)).border(1.dp,Color(m.accent),RoundedCornerShape(18.dp)).clickable{selected=machines.indexOf(m);grid=List(20){m.symbols.random()};lines=emptyList();go("game")}.padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(m.icon,fontSize=40.sp);Text(m.name,color=Color(m.accent),fontWeight=FontWeight.Bold);Text("ИГРАТЬ")}}}};Row{TextButton(onClick={go("shop")}){Text("🛍 Магазин")};TextButton(onClick={go("bonus")}){Text("🎁 Бонусы")}}}
 "game"->{Text(game.icon+" "+game.name,color=accent,fontSize=25.sp,fontWeight=FontWeight.Black);Box(Modifier.fillMaxWidth().aspectRatio(1.25f).background(bg,RoundedCornerShape(12.dp))){Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(4.dp)){for(r in 0..3){Row(Modifier.weight(1f),horizontalArrangement=Arrangement.spacedBy(4.dp)){for(c in 0..4){val i=r*5+c;Box(Modifier.weight(1f).fillMaxHeight().background(accent.copy(alpha=if(lines.any{i in it.cells}) .55f else .17f),RoundedCornerShape(8.dp)).border(1.dp,accent,RoundedCornerShape(8.dp)),contentAlignment=Alignment.Center){Text(grid[i],fontSize=27.sp)}}}}};Canvas(Modifier.matchParentSize()){for(l in lines){val a=l.cells.first();val b=l.cells.last();val w=size.width/5;val h=size.height/4;drawLine(listOf(Color.Yellow,Color.Cyan,Color.Magenta,Color.Green)[l.direction],Offset((a%5+.5f)*w,(a/5+.5f)*h),Offset((b%5+.5f)*w,(b/5+.5f)*h),strokeWidth=4.dp.toPx())}}};Text("3+ одинаковых подряд • все направления • пересечения оплачиваются отдельно");Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){Button(onClick={bet=(bet-5).coerceAtLeast(5)},enabled=!busy){Text("−")};Text("Ставка $bet",color=accent,fontSize=20.sp);Button(onClick={bet=(bet+5).coerceAtMost(100)},enabled=!busy){Text("+")}};Button(onClick={spin(false)},enabled=!busy&&coins>=bet,modifier=Modifier.fillMaxWidth()){Text(if(busy)"Вращение…" else "КРУТИТЬ • $bet 🪙")};OutlinedButton(onClick={spin(true)},enabled=!busy&&tickets>0,modifier=Modifier.fillMaxWidth()){Text("Вращение за билет")};Text(msg,color=accent)}
 "profile"->{Text("МОЙ АККАУНТ",fontSize=24.sp,color=accent);val bitmap=remember(photo){runCatching{ctx.contentResolver.openInputStream(android.net.Uri.parse(photo))?.use{BitmapFactory.decodeStream(it)}}.getOrNull()};if(bitmap!=null)Image(bitmap.asImageBitmap(),"Фото профиля",Modifier.size(100.dp).clip(RoundedCornerShape(50.dp)))else Text("👤",fontSize=60.sp);Button(onClick={picker.launch(arrayOf("image/*"))}){Text("Выбрать фото")};OutlinedTextField(name,{name=it.take(40);save()},label={Text("Имя")});Button(onClick={datePick()}){Text("Дата рождения: $birth")};Text("Выигрышей: $won • проигрышей: $lost");Text("Всего: ${won+lost} • крупнейший выигрыш: $biggest");Text("История игр",fontSize=22.sp);val arr=JSONArray(history);for(i in 0 until arr.length()){val h=arr.getJSONObject(i);Text(h.getString("game")+" • "+java.text.DateFormat.getDateTimeInstance().format(java.util.Date(h.getLong("time")))+"\nСтавка: "+h.getInt("bet")+ (if(h.optBoolean("ticket"))" (билет)" else " монет")+" • Выплата: "+h.getInt("payout")+" • Итог: "+h.getInt("net"));HorizontalDivider()}}
 "settings"->{Text("НАСТРОЙКИ",fontSize=24.sp,color=accent);Row(verticalAlignment=Alignment.CenterVertically){Text("Звуковые эффекты",Modifier.weight(1f));Switch(sound,{sound=it;save()})};Text("Громкость ${(volume*100).toInt()}%");Slider(volume,{volume=it;save()});Row(verticalAlignment=Alignment.CenterVertically){Text("Анимации",Modifier.weight(1f));Switch(anim,{anim=it;save()})};Text("Русский • 3.0 Arcade\nДанные хранятся на устройстве. Реальные деньги не используются.")}
 "shop"->{Text("Магазин виртуальных билетов",fontSize=22.sp);for((n,c) in listOf(5 to 125,12 to 250,30 to 500)){Button(onClick={coins-=c;tickets+=n;save()},enabled=coins>=c){Text("$n билетов за $c монет")}}}
 "bonus"->{Text("Ежедневный бонус",fontSize=24.sp);val day=java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(java.util.Date());var claimed by remember{mutableStateOf(prefs.getString("daily","")==day)};Button(onClick={coins+=500;tickets+=10;claimed=true;prefs.edit().putString("daily",day).apply();save()},enabled=!claimed){Text(if(claimed)"Получено сегодня" else "+500 монет и 10 билетов")}}
 };Text("18+ • Только виртуальные монеты • Без денежных ставок",color=Color.LightGray,fontSize=11.sp)
 }
 }}
}
