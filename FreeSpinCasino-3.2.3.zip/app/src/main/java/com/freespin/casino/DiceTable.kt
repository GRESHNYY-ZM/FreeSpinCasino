package com.freespin.casino
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.*

@Composable internal fun DiceTable(frame:DiceFrame,accent:Color){
 Canvas(Modifier.fillMaxWidth().height(250.dp).background(Color(0xFF63401E),RoundedCornerShape(20.dp)).border(2.dp,accent,RoundedCornerShape(20.dp))){
 val r=min(size.width/13f,size.height/9f);val origin=Offset(size.width/2,size.height*.64f)
 fun project(p:DVec)=Offset(origin.x+p.x*r,origin.y+(p.y*.65f-p.z*.76f)*r)
 drawRoundRect(Brush.radialGradient(listOf(Color(0xFF28644D),Color(0xFF102C23))),topLeft=Offset(9.dp.toPx(),9.dp.toPx()),size=Size(size.width-18.dp.toPx(),size.height-18.dp.toPx()),cornerRadius=androidx.compose.ui.geometry.CornerRadius(14.dp.toPx()))
 fun path(points:List<Offset>)=Path().apply{moveTo(points.first().x,points.first().y);points.drop(1).forEach{lineTo(it.x,it.y)};close()}
 val view=DVec(0f,.76f,.65f)
 val grain=kotlin.random.Random(42)
 repeat(850){ val x=grain.nextFloat()*(size.width-28.dp.toPx())+14.dp.toPx();val y=grain.nextFloat()*(size.height-28.dp.toPx())+14.dp.toPx();drawCircle(Color.White.copy(alpha=.035f),.55.dp.toPx(),Offset(x,y)) }
 for(pose in frame.poses){val c=project(pose.p.copy(z=0f));drawOval(Brush.radialGradient(listOf(Color.Black.copy(alpha=.45f),Color.Transparent),c,r*1.6f),Offset(c.x-r*1.6f,c.y-r*.65f),Size(r*3.2f,r*1.3f))}
 for(pose in frame.poses.sortedBy{it.p.dot(view)}){
 // Bevel strips bridge the inset faces along each cube edge.
 val bevel=.13f
 for(n in diceNormals) for(m in diceNormals){if(n.dot(m)!=0f || diceNormals.indexOf(n)>=diceNormals.indexOf(m))continue;val normal=pose.q.rotate((n+m).unit());if(normal.dot(view)<=0f)continue;val t=n.cross(m);val a=n+m*(1f-bevel);val b=m+n*(1f-bevel);val poly=listOf(a+t*(1f-bevel),b+t*(1f-bevel),b-t*(1f-bevel),a-t*(1f-bevel));val l=(.72f+.22f*normal.dot(DVec(-.35f,-.2f,.91f))).coerceIn(.45f,.96f);drawPath(path(poly.map{project(pose.p+pose.q.rotate(it))}),Color(l,l*.98f,l*.92f))}
 for(n in diceNormals.filter{it.x!=0f}) for(m in diceNormals.filter{it.y!=0f}) for(k in diceNormals.filter{it.z!=0f}){val normal=pose.q.rotate((n+m+k).unit());if(normal.dot(view)<=0f)continue;val c=n+m+k;val poly=listOf(c-(m+k)*bevel,c-(n+k)*bevel,c-(n+m)*bevel);val l=(.72f+.22f*normal.dot(DVec(-.35f,-.2f,.91f))).coerceIn(.45f,.96f);drawPath(path(poly.map{project(pose.p+pose.q.rotate(it))}),Color(l,l*.98f,l*.92f))}
 for((i,n) in diceNormals.withIndex()){val normal=pose.q.rotate(n);if(normal.dot(view)<=0f)continue
 val u=if(abs(n.z)>.5f)DVec(1f,0f,0f) else DVec(0f,0f,1f);val v=n.cross(u)
 fun point(a:Float,b:Float)=project(pose.p+pose.q.rotate(n+u*a+v*b))
 val face=path(listOf(point(-.87f,-.87f),point(.87f,-.87f),point(.87f,.87f),point(-.87f,.87f)))
 val light=(.70f+.24f*normal.dot(DVec(-.35f,-.2f,.91f))).coerceIn(.45f,.96f)
 drawPath(face,Brush.linearGradient(listOf(Color(light,light*.98f,light*.91f),Color(light*.83f,light*.81f,light*.76f)),point(-1f,-1f),point(1f,1f)))
 
 val dots=when(i+1){1->listOf(4);2->listOf(0,8);3->listOf(0,4,8);4->listOf(0,2,6,8);5->listOf(0,2,4,6,8);else->listOf(0,2,3,5,6,8)}
 for(d in dots){val a=(d%3-1)*.55f;val b=(d/3-1)*.55f;val pip=path((0..23).map{j->val t=j*2*PI/24;point(a+.14f*cos(t).toFloat(),b+.14f*sin(t).toFloat())});drawPath(pip,Color(0xFF77736B),style=Stroke(width=2.dp.toPx()));drawPath(pip,Brush.linearGradient(listOf(Color(0xFF101014),Color(0xFF55535A)),point(a-.14f,b-.14f),point(a+.14f,b+.14f)))}
 }
 }
 }
}
