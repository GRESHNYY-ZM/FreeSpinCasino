package com.freespin.casino

import kotlin.math.*
import kotlin.random.Random

internal data class DVec(val x:Float,val y:Float,val z:Float) {
 operator fun plus(b:DVec)=DVec(x+b.x,y+b.y,z+b.z)
 operator fun minus(b:DVec)=this+b*(-1f)
 operator fun times(k:Float)=DVec(x*k,y*k,z*k)
 fun dot(b:DVec)=x*b.x+y*b.y+z*b.z
 fun cross(b:DVec)=DVec(y*b.z-z*b.y,z*b.x-x*b.z,x*b.y-y*b.x)
 fun norm()=sqrt(dot(this))
 fun unit()=this*(1f/norm().coerceAtLeast(.00001f))
}
internal data class DQuat(val w:Float,val x:Float,val y:Float,val z:Float){
 operator fun times(b:DQuat)=DQuat(w*b.w-x*b.x-y*b.y-z*b.z,w*b.x+x*b.w+y*b.z-z*b.y,w*b.y-x*b.z+y*b.w+z*b.x,w*b.z+x*b.y-y*b.x+z*b.w)
 fun unit():DQuat {val n=sqrt(w*w+x*x+y*y+z*z);return DQuat(w/n,x/n,y/n,z/n)}
 fun rotate(v:DVec):DVec {val u=DVec(x,y,z);return v+u.cross(v)*(2*w)+u.cross(u.cross(v))*2f}
 companion object {fun axis(v:DVec,a:Float):DQuat {val u=v.unit()*sin(a/2);return DQuat(cos(a/2),u.x,u.y,u.z)}}
}
internal val diceNormals=listOf(DVec(0f,0f,1f),DVec(1f,0f,0f),DVec(0f,1f,0f),DVec(0f,-1f,0f),DVec(-1f,0f,0f),DVec(0f,0f,-1f))
internal data class DicePose(val p:DVec,val q:DQuat){fun top()=diceNormals.indices.maxByOrNull{q.rotate(diceNormals[it]).z}!!+1}
internal data class DiceFrame(val poses:List<DicePose>,val impact:Boolean=false)
internal object DicePhysics {
 private val up=DVec(0f,0f,1f)
 private val corners= listOf(-1f,1f).flatMap{x->listOf(-1f,1f).flatMap{y->listOf(-1f,1f).map{z->DVec(x,y,z)}}}
 private data class Body(var p:DVec,var v:DVec,var q:DQuat,var spin:DVec)
 private fun align(q:DQuat):DQuat {val n=q.rotate(diceNormals[DicePose(up,q).top()-1]);val a=n.cross(up);return if(a.norm()<.0001f)q else (DQuat.axis(a,acos(n.z.coerceIn(-1f,1f)))*q).unit()}
 fun roll(random:Random=Random.Default):List<DiceFrame>{
 fun rnd(a:Float,b:Float)=a+random.nextFloat()*(b-a)
 val bodies=(0..1).map{i->Body(DVec(if(i==0)-2.5f else 2.5f,rnd(-1f,1f),rnd(2.5f,3.5f)),DVec(rnd(-4f,4f),rnd(-3f,3f),rnd(3f,6f)),DQuat.axis(DVec(rnd(-1f,1f),rnd(-1f,1f),rnd(-1f,1f)),rnd(0f,6.28f)),DVec(rnd(-12f,12f),rnd(-12f,12f),rnd(-12f,12f)))}
 val frames=mutableListOf<DiceFrame>();val dt=1f/120f
 repeat(360){step->var impact=false
 for(b in bodies){b.v=b.v+DVec(0f,0f,-18f)*dt;b.p=b.p+b.v*dt;val speed=b.spin.norm();if(speed>.0001f)b.q=(DQuat.axis(b.spin,speed*dt)*b.q).unit()
 val pts=corners.map{b.q.rotate(it)};val low=pts.minByOrNull{it.z}!!
 if(b.p.z+low.z<0f){b.p=b.p+up*(-b.p.z-low.z);val contact=b.v+b.spin.cross(low);if(contact.z<0f){val j=-1.35f*contact.z/(1f+1.5f*low.cross(up).dot(low.cross(up)));b.v=b.v+up*j;b.spin=b.spin+low.cross(up)*(1.5f*j);if(j>1.2f)impact=true};b.v=DVec(b.v.x*.96f,b.v.y*.96f,b.v.z);b.spin=b.spin*.96f}
 val ex=pts.maxOf{abs(it.x)};val ey=pts.maxOf{abs(it.y)};val bx=5.3f-ex;val by=2.9f-ey
 if(abs(b.p.x)>bx){b.p=DVec(b.p.x.coerceIn(-bx,bx),b.p.y,b.p.z);b.v=DVec(-b.v.x*.55f,b.v.y,b.v.z);impact=true};if(abs(b.p.y)>by){b.p=DVec(b.p.x,b.p.y.coerceIn(-by,by),b.p.z);b.v=DVec(b.v.x,-b.v.y*.55f,b.v.z);impact=true}
 }
 val a=bodies[0];val b=bodies[1];val delta=b.p-a.p;val dist=delta.norm();if(dist<3.0f&&dist>.001f){val n=delta.unit();val correction=n*((3f-dist)*.5f);a.p=a.p-correction;b.p=b.p+correction;val rel=(b.v-a.v).dot(n);if(rel<0){val impulse=n*(-rel*.75f);a.v=a.v-impulse;b.v=b.v+impulse;impact=true}}
 if(step%2==0)frames.add(DiceFrame(bodies.map{DicePose(it.p,it.q)},impact))
 }
 val final=bodies.map{DicePose(DVec(it.p.x.coerceIn(-3.8f,3.8f),it.p.y.coerceIn(-1.5f,1.5f),1f),align(it.q))}.toMutableList()
 if((final[0].p-final[1].p).norm()<2.9f){final[0]=final[0].copy(p=DVec(-1.7f,final[0].p.y,1f));final[1]=final[1].copy(p=DVec(1.7f,final[1].p.y,1f))}
 frames.add(DiceFrame(final));return frames
 }
 fun initial():DiceFrame=DiceFrame(listOf(DicePose(DVec(-2f,0f,1f),DQuat(1f,0f,0f,0f)),DicePose(DVec(2f,0f,1f),DQuat(1f,0f,0f,0f))))
}
