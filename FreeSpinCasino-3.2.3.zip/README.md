# FreeSpinCasino 3.0 Arcade
Rebuilt from 2.1.1. Six themed machines, 5x4 grid, all contiguous runs of 3+ symbols in four directions; overlapping distinct runs each pay independently. Virtual coins only. Bets 5–100 in steps of 5. Local profile, self-declared age gate, last 500 results, lifetime counts, photo picker, sound effects, splash and icon. No real money. No background music or vibration implemented. Android build not tested locally. Existing GitHub workflow must remain in repository; replace ZIP contents using the filename it expects.

## 3.1.6
UI refresh, fixed header, compact rewards, rules dialog, colored roulette history, shaded symbols. Balance simulation: 200000 grids; see tests/balance-3.1.6.txt. Android build not verified locally.

3.1.7: themed symbol compositions in menu, metallic reel gradients, payout examples and separate net result, screen-specific scroll position, roulette and dice shading. Existing payout algorithm and persistence unchanged. Android build not verified in this environment.

## 3.1.8
32 existing symbol PNGs re-lit and resized to 512x512, preserving transparency and resource names. This is a procedural visual pass, not a full original redraw. Gameplay and persistence unchanged. Android build not tested.

## 3.1.9
Virtual coin roulette and dice wagers, independent number/color stakes, animated dice, menu cards. Payout unit checks passed. Android build not verified.

3.2.2: fixed face numbering, rigid-body approximation, gravity, contact impulses, approximate sphere collisions, final face alignment. Android build not tested.

3.2.3: beveled dice mesh, shaded pips and procedural felt grain. Physics unchanged; Android build not verified.
