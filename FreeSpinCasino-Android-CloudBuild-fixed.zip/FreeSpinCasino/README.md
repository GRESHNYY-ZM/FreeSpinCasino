# FREE SPIN CASINO — Android MVP 1.1

Бесплатная аркадная игра на Kotlin + Jetpack Compose. Только виртуальные монеты и вращения; нет денежных ставок, покупок или вывода средств.

## Реализовано
- Главное меню с пятью слотами: Lucky Stars, Fruit Party, Galaxy Spin, Treasure Gold, Magic Forest.
- Анимированное вращение символов с постепенным замедлением.
- Звуковые сигналы вращения и результата; переключатель звука.
- Эффект увеличения символов при победе/получении бонуса.
- Бесплатные вращения и ежедневный бонус (+5 вращений, +100 монет).
- Сохранение прогресса и настройки звука на устройстве.
- Экран правил и обозначение демо-режима.

## Сборка APK
1. Установите Android Studio, JDK 17 и Android SDK Platform 35.
2. Откройте папку `FreeSpinCasino` в Android Studio.
3. Дождитесь Gradle Sync (при первой сборке нужен доступ к Google/Maven repositories).
4. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

Можно собрать командой `gradle :app:assembleDebug`, если Gradle и Android SDK настроены.

Все игровые результаты демонстрационные; виртуальные монеты не имеют денежной ценности.

## Облачная сборка без компьютера
В проект добавлен GitHub Actions workflow `.github/workflows/build-apk.yml`.
Загрузите содержимое папки проекта в GitHub-репозиторий. Затем откройте вкладку **Actions**, выберите **Build Android APK** и нажмите **Run workflow** (если сборка не запустилась автоматически после загрузки в `main`). После успешной сборки откройте запуск workflow и скачайте artifact **FreeSpinCasino-debug-apk**. Внутри будет `app-debug.apk`.
