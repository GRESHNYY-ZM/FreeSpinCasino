package com.freespin.casino

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Night = Color(0xFF0B0820)
private val Panel = Color(0xFF21183D)
private val Gold = Color(0xFFFFD166)
private val Pink = Color(0xFFFF4F9A)
private val Mint = Color(0xFF54E0C1)
private data class SlotTheme(val name:String,val subtitle:String,val icon:String,val symbols:List<String>,val accent:Color,val payout:Int)
private val machines = listOf(
 SlotTheme("LUCKY STARS","Классика удачи","🌟",listOf("⭐","💎","7️⃣","🍒","🔔","👑"),Gold,120),
 SlotTheme("FRUIT PARTY","Сочный фруктовый микс","🍉",listOf("🍒","🍋","🍉","🍇","🍊","🍓"),Color(0xFFFF7B54),100),
 SlotTheme("GALAXY SPIN","Космические символы","🚀",listOf("🌙","🪐","🚀","👽","☄️","🌌"),Color(0xFF8C83FF),150),
 SlotTheme("TREASURE GOLD","Охота за сокровищами","👑",listOf("👑","💰","🏆","💎","🗝️","⚱️"),Gold,180),
 SlotTheme("MAGIC FOREST","Волшебный лес","🧙",listOf("🍀","🦄","🧙","🦋","🌈","🌳"),Mint,140)
)
class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{CasinoApp()}} }

@OptIn(ExperimentalAnimationApi::class)
@Composable fun CasinoApp(){
 val context= LocalContext.current
 val prefs= remember{context.getSharedPreferences("casino_demo",0)}
 val scope= rememberCoroutineScope()
 val tone= remember{ToneGenerator(AudioManager.STREAM_MUSIC,65)}
 DisposableEffect(Unit){onDispose{tone.release()}}
 var coins by remember{mutableIntStateOf(prefs.getInt("coins",500))}
 var spins by remember{mutableIntStateOf(prefs.getInt("spins",10))}
 var totalWins by remember{mutableIntStateOf(prefs.getInt("wins",0))}
 var selected by remember{mutableIntStateOf(0)}
 var reels by remember{mutableStateOf(listOf("⭐","💎","7️⃣"))}
 var message by remember{mutableStateOf("Выбери автомат и испытай удачу!")}
 var spinning by remember{mutableStateOf(false)}
 var soundOn by remember{mutableStateOf(prefs.getBoolean("sound",true))}
 var showRules by remember{mutableStateOf(false)}
 val machine=machines[selected]
 val winScale by animateFloatAsState(if(message.startsWith("ПОБЕДА")||message.startsWith("БОНУС"))1.07f else 1f,tween(260),label="win")
 fun save(){prefs.edit().putInt("coins",coins).putInt("spins",spins).putInt("wins",totalWins).putBoolean("sound",soundOn).apply()}
 fun beep(code:Int){if(soundOn)tone.startTone(code,130)}
 fun spin(){
  if(spinning)return
  if(spins<=0){message="Бесплатные вращения закончились. Забери ежедневный бонус 🎁";beep(ToneGenerator.TONE_PROP_NACK);return}
  spins--;spinning=true;message="Барабаны вращаются...";save()
  scope.launch{
   repeat(22){step->reels=List(3){machine.symbols.random()};beep(ToneGenerator.TONE_PROP_BEEP);delay(55L+step*5L)}
   val result=List(3){machine.symbols.random()};reels=result
   val payout=when{result.distinct().size==1->machine.payout;result[0]==result[1]||result[1]==result[2]||result[0]==result[2]->25;else->0}
   if(payout>0){coins+=payout;totalWins+=payout;message="ПОБЕДА! +$payout виртуальных монет 🎉";beep(ToneGenerator.TONE_PROP_ACK)}else{message="Почти! Следующий прокрут может быть удачным ✨";beep(ToneGenerator.TONE_PROP_NACK)}
   spinning=false;save()
  }
 }
 fun daily(){val today=SimpleDateFormat("yyyyMMdd",Locale.US).format(Date());if(prefs.getString("daily","")==today){message="Ежедневный бонус уже получен. Возвращайся завтра!"}else{spins+=5;coins+=100;prefs.edit().putString("daily",today).apply();message="БОНУС! +5 вращений и +100 монет 🎁";beep(ToneGenerator.TONE_PROP_ACK);save()}}
 MaterialTheme(colorScheme=darkColorScheme(primary=Gold,background=Night,surface=Panel)){
  Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF30134F),Night,Color(0xFF080715))))) {
   Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(15.dp)){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Column{Text("✦ FREE SPIN",color=Gold,fontSize=25.sp,fontWeight=FontWeight.Black);Text("CASINO ARCADE",color=Color.LightGray,fontSize=10.sp,letterSpacing=3.sp)};Surface(shape=CircleShape,color=Panel,border=BorderStroke(1.dp,Gold.copy(alpha=.45f))){Text(if(soundOn)"🔊" else "🔇",Modifier.clickable{soundOn=!soundOn;save()}.padding(12.dp),fontSize=19.sp)}}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){StatCard("🪙 МОНЕТЫ",coins.toString(),Modifier.weight(1f));StatCard("🎟 ВРАЩЕНИЯ",spins.toString(),Modifier.weight(1f));StatCard("🏆 ВЫИГРЫШ",totalWins.toString(),Modifier.weight(1f))}
    Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(8.dp)){
     Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Text("ВЫБЕРИ СВОЙ СЛОТ",color=Color.White,fontSize=16.sp,fontWeight=FontWeight.ExtraBold,letterSpacing=1.sp);Text("5 АВТОМАТОВ",color=Gold,fontSize=10.sp,fontWeight=FontWeight.Bold)}
     machines.forEachIndexed{index,item->val active=selected==index;Row(Modifier.fillMaxWidth().background(if(active)item.accent.copy(alpha=.22f)else Panel,RoundedCornerShape(17.dp)).clickable(enabled=!spinning){selected=index;reels=List(3){item.symbols.random()};message="Добро пожаловать в ${item.name}!"}.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Text(item.icon,fontSize=27.sp);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(item.name,color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=13.sp);Text(item.subtitle,color=Color.LightGray,fontSize=11.sp)};Text(if(active)"ВЫБРАНО ✓" else "ИГРАТЬ ›",color=item.accent,fontSize=9.sp,fontWeight=FontWeight.Black)}}
    }
    Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Panel,Color(0xFF17112D))),RoundedCornerShape(26.dp)).padding(17.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(13.dp)){
     Text("${machine.icon}  ${machine.name}  ${machine.icon}",color=machine.accent,fontSize=18.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp)
     Row(Modifier.fillMaxWidth().background(Color(0xFF090717),RoundedCornerShape(18.dp)).padding(10.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){reels.forEach{symbol->Box(Modifier.weight(1f).height(86.dp).background(Brush.verticalGradient(listOf(Color(0xFFFFF8E8),Color(0xFFFFDFA0))),RoundedCornerShape(13.dp)),contentAlignment=Alignment.Center){AnimatedContent(symbol,transitionSpec={fadeIn(tween(100)) togetherWith fadeOut(tween(70))},label="reel"){shown->Text(shown,fontSize=36.sp,modifier=Modifier.scale(winScale))}}}}
     Text(message,color=if(message.startsWith("ПОБЕДА")||message.startsWith("БОНУС"))Gold else Color.White,fontSize=13.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center,minLines=2)
     Button(onClick={spin()},enabled=spins>0&&!spinning,modifier=Modifier.fillMaxWidth().height(56.dp),colors=ButtonDefaults.buttonColors(containerColor=Pink,disabledContainerColor=Color.Gray),shape=RoundedCornerShape(17.dp)){Text(if(spinning)"⏳ ВРАЩЕНИЕ..." else "🎰 КРУТИТЬ БЕСПЛАТНО",fontSize=16.sp,fontWeight=FontWeight.Black)}
     OutlinedButton(onClick={daily()},enabled=!spinning,modifier=Modifier.fillMaxWidth().height(50.dp),shape=RoundedCornerShape(16.dp),border=BorderStroke(1.dp,Gold),colors=ButtonDefaults.outlinedButtonColors(contentColor=Gold)){Text("🎁 ЕЖЕДНЕВНЫЙ БОНУС +5 СПИНОВ",fontWeight=FontWeight.Bold,fontSize=12.sp)}
     Text("Три одинаковых символа: до ${machine.payout} монет • Два одинаковых: +25",color=Color.LightGray,fontSize=10.sp,textAlign=TextAlign.Center)
    }
    OutlinedButton(onClick={showRules=true},modifier=Modifier.fillMaxWidth(),border=BorderStroke(1.dp,Color.White.copy(alpha=.25f)),colors=ButtonDefaults.outlinedButtonColors(contentColor=Color.LightGray)){Text("ℹ️ ПРАВИЛА ИГРЫ")}
    Text("ДЕМО-РЕЖИМ • БЕЗ ДЕНЕЖНЫХ СТАВОК И ВЫВОДА СРЕДСТВ\nВИРТУАЛЬНЫЕ МОНЕТЫ НЕ ИМЕЮТ ДЕНЕЖНОЙ ЦЕННОСТИ",color=Color(0xFFAAA3BE),fontSize=9.sp,textAlign=TextAlign.Center,lineHeight=14.sp)
   }
   if(showRules)AlertDialog(onDismissRequest={showRules=false},title={Text("Правила FREE SPIN CASINO",color=Gold,fontWeight=FontWeight.Bold)},text={Text("Это бесплатная аркадная игра. Каждое вращение расходует один билет. Два одинаковых символа приносят 25 виртуальных монет, три одинаковых — награду выбранного автомата. Ежедневный бонус доступен раз в день: +5 вращений и +100 монет. Монеты нельзя купить, обменять или вывести.",color=Color.White)},confirmButton={TextButton(onClick={showRules=false}){Text("ПОНЯТНО",color=Gold)}},containerColor=Panel)
  }
 }
}
@Composable fun StatCard(title:String,value:String,modifier:Modifier=Modifier){Column(modifier.background(Panel,RoundedCornerShape(16.dp)).padding(vertical=12.dp,horizontal=5.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(title,color=Color.LightGray,fontSize=9.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center);Spacer(Modifier.height(5.dp));Text(value,color=Gold,fontSize=20.sp,fontWeight=FontWeight.Black)}}
