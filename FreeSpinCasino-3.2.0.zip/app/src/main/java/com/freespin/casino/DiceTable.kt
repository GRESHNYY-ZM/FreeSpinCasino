package com.freespin.casino

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.*

private data class V(val x:Float,val y:Float,val z:Float) {
    operator fun plus(v:V)=V(x+v.x,y+v.y,z+v.z)
    operator fun times(k:Float)=V(x*k,y*k,z*k)
    fun rotate(a:Float,b:Float,c:Float):V {
        val u=V(x,y*cos(a)-z*sin(a),y*sin(a)+z*cos(a))
        val v=V(u.x*cos(b)+u.z*sin(b),u.y,-u.x*sin(b)+u.z*cos(b))
        return V(v.x*cos(c)-v.y*sin(c),v.x*sin(c)+v.y*cos(c),v.z)
    }
}
private data class Face(val n:V,val u:V,val v:V,val number:Int)
private fun facePath(points:List<Offset>)=Path().apply { moveTo(points[0].x,points[0].y);points.drop(1).forEach{lineTo(it.x,it.y)};close() }

@Composable
internal fun DiceTable(dice:List<Int>,progress:Float,busy:Boolean,accent:Color) {
    Canvas(Modifier.fillMaxWidth().height(230.dp).background(Brush.radialGradient(listOf(Color(0xFF28644D),Color(0xFF102C23))),RoundedCornerShape(20.dp)).border(2.dp,accent,RoundedCornerShape(20.dp))) {
        val t=if(busy)progress.coerceIn(0f,1f) else 1f
        val r=min(size.width*.125f,size.height*.23f)
        for(index in 0..1) {
            val sign=if(index==0) -1f else 1f
            val phase=(t*3f).coerceAtMost(3f)
            val lift=abs(sin(phase*PI).toFloat())*(1-t)*size.height*.27f
            val x=size.width*(.5f+sign*(.22f-.11f*(1-t)))
            val y=size.height*.58f-lift
            val a=.34f+(1-t)*sin(t*19f+index)*2.8f+ (1-t)*6.283185f
            val b=sign*.48f+(1-t)*sin(t*13f+index)*3.5f
            val c=sign*.12f+(1-t)*sin(t*17f)*2f
            drawOval(Color.Black.copy(alpha=.32f*(1-lift/size.height)),Offset(x-r,y+lift+r*.68f),Size(r*2,r*.42f))
            val front=dice.getOrElse(index){1}
            val sides=(1..6).filter{it!=front&&it!=7-front}
            val faces=listOf(
                Face(V(0f,0f,1f),V(1f,0f,0f),V(0f,1f,0f),front),
                Face(V(0f,0f,-1f),V(-1f,0f,0f),V(0f,1f,0f),7-front),
                Face(V(1f,0f,0f),V(0f,0f,-1f),V(0f,1f,0f),sides[0]),
                Face(V(-1f,0f,0f),V(0f,0f,1f),V(0f,1f,0f),7-sides[0]),
                Face(V(0f,-1f,0f),V(1f,0f,0f),V(0f,0f,1f),sides.first{it!=sides[0]&&it!=7-sides[0]}),
                Face(V(0f,1f,0f),V(1f,0f,0f),V(0f,0f,-1f),7-sides.first{it!=sides[0]&&it!=7-sides[0]})
            )
            fun project(v:V):Offset { val q=v.rotate(a,b,c);val k=4.8f/(4.8f-q.z);return Offset(x+q.x*r*k,y+q.y*r*k) }
            for(f in faces.sortedBy{it.n.rotate(a,b,c).z}) {
                val normal=f.n.rotate(a,b,c)
                if(normal.z<=.21f)continue
                fun point(u:Float,v:Float)=project(f.n+f.u*u+f.v*v)
                val path=facePath(listOf(point(-1f,-1f),point(1f,-1f),point(1f,1f),point(-1f,1f)))
                val light=(.72f+.18f*normal.z-.16f*normal.y-.10f*normal.x).coerceIn(.48f,1f)
                drawPath(path,Color(light,light*.98f,light*.92f))
                drawPath(path,Color(0xFFECE5D7),style=Stroke(width=1.4.dp.toPx()))
                val dots=when(f.number){1->listOf(4);2->listOf(0,8);3->listOf(0,4,8);4->listOf(0,2,6,8);5->listOf(0,2,4,6,8);else->listOf(0,2,3,5,6,8)}
                for(dot in dots){val u=(dot%3-1)*.55f;val v=(dot/3-1)*.55f
                    val pip=facePath((0..23).map{j->val angle=j*2*PI/24;point(u+.14f*cos(angle).toFloat(),v+.14f*sin(angle).toFloat())})
                    drawPath(pip,Color(0xFF24232A))
                }
            }
        }
    }
}
