package com.freespin.casino

import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

private val bg = Color(0xFF070512)
private val panel = Color(0xFF17112B)
private val gold = Color(0xFFFFD76A)
private val neonPink = Color(0xFFFF43C8)
private val cyan = Color(0xFF55E8FF)

private data class Slot(
    val name: String, val subtitle: String, val emoji: String,
    val symbols: List<String>, val accent: Color, val bet: Int, val jackpot: Int,
    val art: String
)
private val slotGames = listOf(
    Slot("STARLIGHT 777","КОСМИЧЕСКИЙ ДЖЕКПОТ","🌌",listOf("⭐","💎","7️⃣","🌙","👑","☄️","🪐","🔮","✨"),gold,25,2500,"✦ 777 ✦"),
    Slot("FRUIT NEON","ФРУКТОВЫЙ ВЗРЫВ","🍒",listOf("🍒","🍋","🍉","🍇","🍊","🍓","🍍","🥝","💥"),Color(0xFFFF805F),20,1800,"FRUIT MIX"),
    Slot("CYBER GALAXY","ЗА ГРАНЬЮ ВСЕЛЕННОЙ","🚀",listOf("👽","🚀","🪐","☄️","🌌","💫","🛸","🌠","🔷"),cyan,30,3000,"CYBER"),
    Slot("GOLD RUSH","ЗОЛОТАЯ ЛИХОРАДКА","👑",listOf("👑","💰","🏆","💎","🗝️","⚱️","🪙","🔱","✨"),gold,35,4000,"GOLD"),
    Slot("MAGIC GARDEN","ВОЛШЕБНЫЙ САД","🦄",listOf("🦄","🍀","🧙","🦋","🌈","🌳","🌸","🍄","💜"),Color(0xFF72E6B5),25,2200,"MAGIC")
)
private data class Win(val cells:List<Int>, val symbol:String, val prize:Int)

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        window.statusBarColor=android.graphics.Color.rgb(7,5,18)
        window.navigationBarColor=android.graphics.Color.rgb(7,5,18)
        setContent { ArcadeApp() }
    }
}

@Composable private fun ArcadeApp(){
    val context=LocalContext.current
    val prefs= remember { context.getSharedPreferences("arcade_v4",0) }
    val scope= rememberCoroutineScope()
    val soundPool= remember {
        SoundPool.Builder().setMaxStreams(4).setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        ).build()
    }
    val spinSound= remember { soundPool.load(context,R.raw.spin,1) }
    val winSound= remember { soundPool.load(context,R.raw.win,1) }
    val tapSound= remember { soundPool.load(context,R.raw.tap,1) }
    DisposableEffect(Unit){ onDispose { soundPool.release() } }

    var coins by remember { mutableIntStateOf(prefs.getInt("coins",2500)) }
    var tickets by remember { mutableIntStateOf(prefs.getInt("tickets",20)) }
    var totalWon by remember { mutableIntStateOf(prefs.getInt("won",0)) }
    var selected by remember { mutableIntStateOf(0) }
    var screen by remember { mutableStateOf("splash") }
    var section by remember { mutableStateOf("home") }
    var soundOn by remember { mutableStateOf(true) }
    var spinning by remember { mutableStateOf(false) }
    var reels by remember { mutableStateOf(List(15){slotGames[0].symbols.random()} ) }
    var wins by remember { mutableStateOf(emptyList<Win>()) }
    var payout by remember { mutableIntStateOf(0) }
    var currentBet by remember { mutableIntStateOf(slotGames[0].bet) }
    var status by remember { mutableStateOf("УДАЧИ! СОБЕРИ 3 И БОЛЕЕ СИМВОЛОВ") }
    val game=slotGames[selected]

    fun save(){ prefs.edit().putInt("coins",coins).putInt("tickets",tickets).putInt("won",totalWon).apply() }
    fun play(id:Int){ if(soundOn) soundPool.play(id,0.9f,0.9f,1,0,1f) }
    fun enterGame(index:Int){
        if(spinning)return
        selected=index
        currentBet=slotGames[index].bet
        reels=List(15){slotGames[index].symbols.random()}
        wins= emptyList(); payout=0
        screen="game"; status="АВТОМАТ ГОТОВ К ИГРЕ"
        play(tapSound)
    }
    fun spin(){
        if(spinning)return
        val g=slotGames[selected]
        if(tickets<=0 && coins<currentBet){status="НЕ ХВАТАЕТ МОНЕТ. УМЕНЬШИ СТАВКУ ИЛИ ЗАБЕРИ БОНУС";return}
        if(tickets>0) tickets-- else coins-=currentBet
        save()
        spinning=true; wins= emptyList(); payout=0; status="БАРАБАНЫ ВРАЩАЮТСЯ..."
        play(spinSound)
        scope.launch {
            try {
                repeat(15){step->
                    reels=List(15){g.symbols[Random.nextInt(g.symbols.size)]}
                    delay(75L + step*8L)
                }
                val finalReels=List(15){g.symbols[Random.nextInt(g.symbols.size)]}
                val found=mutableListOf<Win>()
                // Горизонтальные линии: совпадение слева направо, минимум 3 символа.
                for(row in 0..2){
                    val symbol=finalReels[row*5]
                    var count=1
                    for(col in 1..4){ if(finalReels[row*5+col]==symbol) count++ else break }
                    if(count>=3) found.add(Win((0 until count).map { row*5+it },symbol,currentBet*(count-2)*4))
                }
                // Вертикальные линии: три одинаковых символа в одном барабане.
                for(col in 0..4){
                    val symbol=finalReels[col]
                    if(finalReels[5+col]==symbol && finalReels[10+col]==symbol)
                        found.add(Win(listOf(col,5+col,10+col),symbol,currentBet*12))
                }
                val prize=found.sumOf{it.prize}
                reels=finalReels
                wins=found
                payout=prize
                if(prize>0){
                    coins+=prize; totalWon+=prize
                    status="ПОБЕДА! ${found.size} ЛИНИЙ • +$prize МОНЕТ"
                    play(winSound)
                } else status="НЕТ ВЫИГРЫША — ПОПРОБУЙ ЕЩЁ!"
                save()
            } catch (_:Exception) {
                status="ПРОКРУТКА ПРЕРВАНА. ПОПРОБУЙ ЕЩЁ РАЗ"
            } finally {
                spinning=false
            }
        }
    }

    LaunchedEffect(Unit){ delay(1900); screen="home" }
    BackHandler(enabled=screen=="game" || screen=="shop" || screen=="bonus"){
        if(!spinning){ screen=if(screen=="game")"home" else "home"; play(tapSound) }
    }

    MaterialTheme(colorScheme=darkColorScheme(primary=gold,background=bg,surface=panel)){
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF21103D),bg,Color(0xFF03020A))))) {
            AnimatedContent(targetState=screen,label="screen") { current ->
                when(current){
                    "splash" -> SplashScreen()
                    "game" -> GameScreen(game,coins,tickets,reels,wins,payout,status,spinning,soundOn,currentBet,
                        onSound={soundOn=it},onBetChange={currentBet=it},onSpin={spin()},onBack={if(!spinning)screen="home"})
                    "shop" -> SimplePage("АРКАДНЫЙ МАГАЗИН","Обменяй виртуальные монеты на билеты",coins,tickets,totalWon,
                        onBack={screen="home"},content={
                            listOf(5 to 125,12 to 250,30 to 500).forEach{(n,cost)->
                                ActionCard("🎟  $n БИЛЕТОВ","$cost 🪙"){ if(coins>=cost){coins-=cost;tickets+=n;save()} }
                            }
                        })
                    "bonus" -> SimplePage("ЕЖЕДНЕВНЫЙ БОНУС","Забирай награду раз в день",coins,tickets,totalWon,
                        onBack={screen="home"},content={
                            ActionCard("ЗАБРАТЬ +500 МОНЕТ И +10 БИЛЕТОВ","БЕСПЛАТНО"){
                                val day=java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(java.util.Date())
                                if(prefs.getString("daily","")!=day){coins+=500;tickets+=10;prefs.edit().putString("daily",day).apply();save()}
                            }
                        })
                    else -> HomeScreen(coins,tickets,totalWon,onChoose={enterGame(it)},onShop={screen="shop"},onBonus={screen="bonus"})
                }
            }
        }
    }
}

@Composable private fun SplashScreen(){
    val infinite= rememberInfiniteTransition(label="splash")
    val scale by infinite.animateFloat(0.92f,1.08f,infiniteRepeatable(tween(700),RepeatMode.Reverse),label="scale")
    val rotation by infinite.animateFloat(-5f,5f,infiniteRepeatable(tween(1200),RepeatMode.Reverse),label="rotation")
    Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
        Box(Modifier.size(190.dp).scale(scale).rotate(rotation).clip(RoundedCornerShape(42.dp)).background(Brush.linearGradient(listOf(Color(0xFFFFD76A),Color(0xFFFF43C8),Color(0xFF743BFF)))).border(4.dp,Color.White.copy(.8f),RoundedCornerShape(42.dp)),contentAlignment=Alignment.Center){
            Text("777",fontSize=58.sp,fontWeight=FontWeight.Black,color=Color(0xFF160A2A))
        }
        Spacer(Modifier.height(28.dp))
        Text("FREE SPIN",fontSize=34.sp,fontWeight=FontWeight.Black,color=gold,letterSpacing=3.sp)
        Text("NEON ARCADE • SLOT CLUB",fontSize=11.sp,color=neonPink,letterSpacing=3.sp)
        Spacer(Modifier.height(30.dp))
        LinearProgressIndicator(Modifier.width(170.dp),color=cyan,trackColor=panel)
    }
}

@Composable private fun HomeScreen(coins:Int,tickets:Int,totalWon:Int,onChoose:(Int)->Unit,onShop:()->Unit,onBonus:()->Unit){
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                Column{Text("FREE SPIN",fontSize=28.sp,fontWeight=FontWeight.Black,color=gold);Text("NEON ARCADE",fontSize=10.sp,color=neonPink,letterSpacing=3.sp)}
                Column(horizontalAlignment=Alignment.End){Text("🪙 $coins",color=gold,fontWeight=FontWeight.Black);Text("🎟 $tickets",color=cyan,fontWeight=FontWeight.Bold)}
            }
        }
        item{
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF44205F),Color(0xFF17112B)))).border(1.dp,neonPink,RoundedCornerShape(22.dp)).padding(18.dp)){
                Column{Text("ВЫБЕРИ СВОЙ АВТОМАТ",color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Black);Text("Пять разных миров. Одна большая аркада.",color=Color.LightGray,fontSize=11.sp)}
            }
        }
        items(slotGames){g->
            val index=slotGames.indexOf(g)
            ArcadeCard(g){onChoose(index)}
        }
        item{
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
                Button(onClick=onShop,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=neonPink,contentColor=bg)){Text("🛍 МАГАЗИН",fontWeight=FontWeight.Black)}
                Button(onClick=onBonus,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=gold,contentColor=bg)){Text("🎁 БОНУС",fontWeight=FontWeight.Black)}
            }
            Text("Всего выиграно: $totalWon монет",Modifier.fillMaxWidth().padding(top=8.dp),color=Color.LightGray,textAlign=TextAlign.Center,fontSize=11.sp)
        }
    }
}

@Composable private fun ArcadeCard(g:Slot,onClick:()->Unit){
    Row(Modifier.fillMaxWidth().height(118.dp).clip(RoundedCornerShape(20.dp)).background(Brush.horizontalGradient(listOf(g.accent.copy(.28f),panel))).border(1.5.dp,g.accent,RoundedCornerShape(20.dp)).clickable(onClick=onClick).padding(14.dp),verticalAlignment=Alignment.CenterVertically){
        Box(Modifier.size(82.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF080612)).border(2.dp,g.accent,RoundedCornerShape(16.dp)),contentAlignment=Alignment.Center){
            Column(horizontalAlignment=Alignment.CenterHorizontally){Text(g.emoji,fontSize=31.sp);Text(g.art,color=g.accent,fontSize=9.sp,fontWeight=FontWeight.Black)}
        }
        Column(Modifier.weight(1f).padding(start=14.dp),verticalArrangement=Arrangement.Center){
            Text(g.name,color=Color.White,fontWeight=FontWeight.Black,fontSize=16.sp)
            Text(g.subtitle,color=g.accent,fontSize=9.sp,fontWeight=FontWeight.Bold)
            Text("СТАВКА ${g.bet} 🪙  •  ДЖЕКПОТ ${g.jackpot}",color=Color.LightGray,fontSize=9.sp)
        }
        Text("▶",color=g.accent,fontSize=22.sp,fontWeight=FontWeight.Black)
    }
}

@Composable private fun GameScreen(g:Slot,coins:Int,tickets:Int,reels:List<String>,wins:List<Win>,payout:Int,status:String,spinning:Boolean,soundOn:Boolean,bet:Int,onSound:(Boolean)->Unit,onBetChange:(Int)->Unit,onSpin:()->Unit,onBack:()->Unit){
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
            Text("‹ НАЗАД",Modifier.clickable(enabled=!spinning,onClick=onBack).padding(8.dp),color=cyan,fontWeight=FontWeight.Black)
            Column(horizontalAlignment=Alignment.End){Text("🪙 $coins",color=gold,fontWeight=FontWeight.Black);Text("🎟 $tickets",color=cyan,fontSize=11.sp)}
        }
        Column(Modifier.fillMaxWidth(),horizontalAlignment=Alignment.CenterHorizontally){
            Text(g.name,color=g.accent,fontSize=23.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp)
            Text(g.subtitle,color=Color.LightGray,fontSize=10.sp,letterSpacing=2.sp)
        }
        // Cabinet-style arcade machine.
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Brush.verticalGradient(listOf(Color(0xFF54316C),Color(0xFF211032),Color(0xFF0B0715)))).border(4.dp,Brush.linearGradient(listOf(gold,g.accent,neonPink,gold)),RoundedCornerShape(28.dp)).padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Brush.horizontalGradient(listOf(g.accent.copy(.3f),Color(0xFF080612),g.accent.copy(.3f)))).padding(10.dp),contentAlignment=Alignment.Center){
                Text("✦  ${g.art}  ✦",color=gold,fontSize=18.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp)
            }
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF030208)).border(3.dp,g.accent,RoundedCornerShape(14.dp)).padding(7.dp)){
              Column(verticalArrangement=Arrangement.spacedBy(5.dp)){
                for(row in 0..2){
                    Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){
                        for(col in 0..4){
                            val idx=row*5+col
                            val highlighted=wins.any{idx in it.cells}
                            Box(Modifier.weight(1f).aspectRatio(0.86f).clip(RoundedCornerShape(8.dp)).background(if(highlighted)Brush.verticalGradient(listOf(Color(0xFFFFF4C8),gold)) else Brush.verticalGradient(listOf(Color(0xFF352B48),Color(0xFF171323)))).border(if(highlighted)3.dp else 1.dp,if(highlighted)neonPink else Color.White.copy(.18f),RoundedCornerShape(8.dp)),contentAlignment=Alignment.Center){
                                Text(reels.getOrElse(idx){"❔"},fontSize=if(col==4)23.sp else 25.sp)
                            }
                        }
                    }
                }
              }
              val pulse= rememberInfiniteTransition(label="winning-lines")
              val lineAlpha by pulse.animateFloat(0.45f,1f,infiniteRepeatable(tween(420),RepeatMode.Reverse),label="line-alpha")
              if(wins.isNotEmpty()) Canvas(Modifier.matchParentSize()) {
                wins.forEach { win ->
                    val first=win.cells.first()
                    val sameRow=win.cells.all { it/5==first/5 }
                    val sameCol=win.cells.all { it%5==first%5 }
                    val stroke=6.dp.toPx()
                    if(sameRow) {
                        val y=size.height*((first/5+0.5f)/3f)
                        drawLine(Color(0xFFFFF07A).copy(alpha=lineAlpha),androidx.compose.ui.geometry.Offset(size.width*0.035f,y),androidx.compose.ui.geometry.Offset(size.width*0.965f,y),strokeWidth=stroke,cap=androidx.compose.ui.graphics.StrokeCap.Round)
                    } else if(sameCol) {
                        val x=size.width*((first%5+0.5f)/5f)
                        drawLine(Color(0xFF55E8FF).copy(alpha=lineAlpha),androidx.compose.ui.geometry.Offset(x,size.height*0.035f),androidx.compose.ui.geometry.Offset(x,size.height*0.965f),strokeWidth=stroke,cap=androidx.compose.ui.graphics.StrokeCap.Round)
                    }
                }
              }
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("5 БАРАБАНОВ",color=cyan,fontSize=10.sp,fontWeight=FontWeight.Black);Text("3 РЯДА • 15 СИМВОЛОВ",color=gold,fontSize=10.sp,fontWeight=FontWeight.Black)}
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF080612)).border(1.dp,g.accent,RoundedCornerShape(12.dp)).padding(10.dp),contentAlignment=Alignment.Center){
                Text(if(payout>0)"★ ВЫИГРЫШ +$payout МОНЕТ ★" else status,color=if(payout>0)gold else Color.White,fontWeight=FontWeight.Black,fontSize=13.sp,textAlign=TextAlign.Center)
            }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF100B1D)).padding(horizontal=10.dp, vertical=7.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
                Text("СТАВКА",color=Color.LightGray,fontWeight=FontWeight.Black,fontSize=12.sp)
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(14.dp)){
                    OutlinedButton(onClick={onBetChange((bet-5).coerceAtLeast(5))},enabled=!spinning && bet>5,contentPadding=PaddingValues(horizontal=13.dp,vertical=2.dp),border=BorderStroke(1.dp,g.accent)){Text("−",fontSize=20.sp,color=g.accent)}
                    Text("$bet 🪙",color=gold,fontWeight=FontWeight.Black,fontSize=18.sp)
                    OutlinedButton(onClick={onBetChange((bet+5).coerceAtMost(500))},enabled=!spinning && bet<500,contentPadding=PaddingValues(horizontal=13.dp,vertical=2.dp),border=BorderStroke(1.dp,g.accent)){Text("+",fontSize=20.sp,color=g.accent)}
                }
            }
            Button(onClick=onSpin,enabled=!spinning,modifier=Modifier.fillMaxWidth().height(62.dp).shadow(if(spinning)0.dp else 12.dp,shape=RoundedCornerShape(18.dp),ambientColor=g.accent,spotColor=g.accent),shape=RoundedCornerShape(18.dp),colors=ButtonDefaults.buttonColors(containerColor=if(spinning)Color.DarkGray else g.accent,contentColor=bg)){
                Text(if(spinning)"БАРАБАНЫ КРУТЯТСЯ..." else "⟳  SPIN  •  $bet 🪙 / 1 🎟",fontSize=18.sp,fontWeight=FontWeight.Black)
            }
            Text("3 символа — ${bet*4} • 4 — ${bet*8} • 5 — ${bet*12} монет",Modifier.fillMaxWidth(),color=Color.LightGray,fontSize=9.sp,textAlign=TextAlign.Center)
        }
        if(wins.isNotEmpty()) Text("ЛИНИИ СОВПАДЕНИЯ: ${wins.size}  •  ГОРИЗОНТАЛЬНЫЕ И ВЕРТИКАЛЬНЫЕ",Modifier.fillMaxWidth(),color=gold,fontSize=10.sp,fontWeight=FontWeight.Black,textAlign=TextAlign.Center)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
            Text("🔊 ЗВУК",color=Color.LightGray,fontSize=11.sp)
            Switch(checked=soundOn,onCheckedChange=onSound)
            Text("ДЖЕКПОТ ${g.jackpot} 🪙",color=gold,fontSize=11.sp,fontWeight=FontWeight.Black)
        }
        Text("Игровые монеты виртуальные. Реальных ставок, платежей и вывода денег нет.",color=Color(0xFF8D849D),fontSize=9.sp,textAlign=TextAlign.Center)
    }
}

@Composable private fun SimplePage(title:String,subtitle:String,coins:Int,tickets:Int,totalWon:Int,onBack:()->Unit,content:@Composable ColumnScope.()->Unit){
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        Text("‹ НАЗАД",Modifier.clickable(onClick=onBack).padding(8.dp),color=cyan,fontWeight=FontWeight.Black)
        Text(title,color=gold,fontSize=24.sp,fontWeight=FontWeight.Black)
        Text(subtitle,color=Color.LightGray,fontSize=12.sp)
        Text("🪙 $coins     🎟 $tickets     🏆 $totalWon",color=cyan,fontWeight=FontWeight.Bold)
        Column(verticalArrangement=Arrangement.spacedBy(12.dp),content=content)
    }
}
@Composable private fun ActionCard(title:String,subtitle:String,onClick:()->Unit){
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(panel).border(1.dp,neonPink,RoundedCornerShape(18.dp)).clickable(onClick=onClick).padding(18.dp)){
        Text(title,color=Color.White,fontWeight=FontWeight.Black);Text(subtitle,color=gold,fontSize=11.sp)
    }
}
