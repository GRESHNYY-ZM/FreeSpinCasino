package com.freespin.casino

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

private val bg = Color(0xFF09051B)
private val panel = Color(0xFF19102F)
private val purple = Color(0xFF9D4EDD)
private val neon = Color(0xFFFF4FD8)
private val gold = Color(0xFFFFD166)
private val cyan = Color(0xFF45E6FF)

private data class Machine(val name:String,val subtitle:String,val icon:String,val symbols:List<String>,val accent:Color,val payout:Int,val bet:Int)
private val games = listOf(
    Machine("STARLIGHT 777","Космический джекпот","🌟",listOf("⭐","💎","7️⃣","🌙","👑","☄️"),gold,500,25),
    Machine("FRUIT NEON","Фруктовый взрыв","🍒",listOf("🍒","🍋","🍉","🍇","🍊","🍓"),Color(0xFFFF785A),350,20),
    Machine("CYBER GALAXY","За гранью вселенной","🚀",listOf("🪐","🚀","👽","☄️","🌌","💫"),cyan,650,30),
    Machine("GOLD RUSH","Золотая лихорадка","👑",listOf("👑","💰","🏆","💎","🗝️","⚱️"),gold,800,35),
    Machine("MAGIC GARDEN","Сказочные символы","🦄",listOf("🍀","🦄","🧙","🦋","🌈","🌳"),Color(0xFF68E6B5),450,25)
)

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); window.statusBarColor=android.graphics.Color.rgb(9,5,27); window.navigationBarColor=android.graphics.Color.rgb(9,5,27); setContent{Casino2()}}
}

@Composable
private fun Casino2(){
    val ctx= LocalContext.current
    val prefs= remember{ctx.getSharedPreferences("free_spin_2",0)}
    val tone= remember{ToneGenerator(AudioManager.STREAM_MUSIC,75)}
    DisposableEffect(Unit){onDispose{tone.release()}}
    val scope= rememberCoroutineScope()
    var coins by remember{mutableIntStateOf(prefs.getInt("coins",1000))}
    var tickets by remember{mutableIntStateOf(prefs.getInt("tickets",20))}
    var wins by remember{mutableIntStateOf(prefs.getInt("wins",0))}
    var chosen by remember{mutableIntStateOf(0)}
    var reels by remember{mutableStateOf(listOf("⭐","💎","7️⃣"))}
    var spinning by remember{mutableStateOf(false)}
    var sound by remember{mutableStateOf(prefs.getBoolean("sound",true))}
    var page by remember{mutableStateOf("home")}
    var note by remember{mutableStateOf("Добро пожаловать! Выбери автомат и начинай игру.")}
    var lastWin by remember{mutableIntStateOf(0)}
    var jackpot by remember{mutableStateOf(false)}
    val game=games[chosen]
    fun save(){prefs.edit().putInt("coins",coins).putInt("tickets",tickets).putInt("wins",wins).putBoolean("sound",sound).apply()}
    fun sfx(type:Int,duration:Int=140){if(sound)tone.startTone(type,duration)}
    fun spin(){
        if(spinning)return
        if(tickets<=0 && coins<game.bet){note="Не хватает монет. Забери ежедневный бонус или зайди в магазин.";sfx(ToneGenerator.TONE_PROP_NACK);return}
        if(tickets>0) tickets-- else coins-=game.bet
        spinning=true;lastWin=0;jackpot=false;note="БАРАБАНЫ ВРАЩАЮТСЯ...";save()
        scope.launch{
            repeat(28){i->
                reels=List(3){game.symbols.random()}
                sfx(ToneGenerator.TONE_PROP_BEEP,55)
                delay(45L+i*4L)
            }
            val result=List(3){game.symbols.random()};reels=result
            val payout=when{
                result.distinct().size==1->game.payout
                result[0]==result[1]||result[1]==result[2]||result[0]==result[2]->game.bet*2
                else->0
            }
            if(payout>0){coins+=payout;wins+=payout;lastWin=payout;jackpot=payout==game.payout;note=if(jackpot)"✦ MEGA WIN! +$payout ✦" else "ПОБЕДА! +$payout монет";sfx(ToneGenerator.TONE_PROP_ACK,500)}
            else{note="Почти! Попробуй ещё раз ✨";sfx(ToneGenerator.TONE_PROP_NACK)}
            spinning=false;save()
        }
    }
    fun daily(){
        val day=SimpleDateFormat("yyyyMMdd",Locale.US).format(Date())
        if(prefs.getString("daily","")==day){note="Ежедневный бонус уже получен. Возвращайся завтра!"}
        else{coins+=500;tickets+=10;prefs.edit().putString("daily",day).apply();note="ЕЖЕДНЕВНЫЙ БОНУС: +500 монет и +10 билетов!";sfx(ToneGenerator.TONE_PROP_ACK);save()}
    }
    MaterialTheme(colorScheme=darkColorScheme(primary=gold,background=bg,surface=panel)){
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF251044),bg,Color(0xFF05030F))))) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=16.dp, vertical=12.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
                    Column { Text("✦ FREE SPIN",color=gold,fontSize=25.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp);Text("NEON CASINO 2.0",color=neon,fontSize=10.sp,letterSpacing=3.sp,fontWeight=FontWeight.Bold) }
                    Surface(color=panel,shape=RoundedCornerShape(50),border=BorderStroke(1.dp,neon.copy(.7f))){Text(if(sound)"🔊" else "🔇",Modifier.clickable{sound=!sound;save()}.padding(12.dp),fontSize=18.sp)}
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Stat("🪙","МОНЕТЫ",coins.toString(),Modifier.weight(1f))
                    Stat("🎟","БИЛЕТЫ",tickets.toString(),Modifier.weight(1f))
                    Stat("🏆","ВЫИГРАНО",wins.toString(),Modifier.weight(1f))
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
                    NavChip("🎰 ИГРА",page=="home",Modifier.weight(1f)){page="home"}
                    NavChip("🛍 МАГАЗИН",page=="shop",Modifier.weight(1f)){page="shop"}
                    NavChip("🎁 БОНУСЫ",page=="bonus",Modifier.weight(1f)){page="bonus"}
                }
                when(page){
                    "shop"->{
                        Header("NEON SHOP","Трать виртуальные монеты на игровые билеты")
                        ShopCard("5 БИЛЕТОВ","125 монет","🎟"){if(coins>=125){coins-=125;tickets+=5;note="Куплено 5 билетов!";save()}else note="Недостаточно монет."}
                        ShopCard("12 БИЛЕТОВ","250 монет","🎫"){if(coins>=250){coins-=250;tickets+=12;note="Куплено 12 билетов!";save()}else note="Недостаточно монет."}
                        ShopCard("25 БИЛЕТОВ","500 монет","🎟"){if(coins>=500){coins-=500;tickets+=25;note="Куплено 25 билетов!";save()}else note="Недостаточно монет."}
                        Text("Монеты и билеты существуют только внутри игры и не имеют денежной стоимости.",color=Color.LightGray,fontSize=11.sp,textAlign=TextAlign.Center)
                    }
                    "bonus"->{
                        Header("DAILY REWARDS","Заходи каждый день за бесплатными наградами")
                        NeonButton("ЗАБРАТЬ ЕЖЕДНЕВНЫЙ БОНУС  +500 🪙  +10 🎟",gold){daily()}
                        Surface(color=panel,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,purple)){Column(Modifier.padding(16.dp)){Text("🏅 ДОСТИЖЕНИЯ",color=gold,fontWeight=FontWeight.Black);Text("Всего выиграно: $wins монет",color=Color.White);Text("Сыграно вращений: ${prefs.getInt("played",0)}",color=Color.LightGray,fontSize=12.sp)}}
                    }
                    else->{
                        Header("CHOOSE YOUR SLOT","Пять уникальных неоновых автоматов")
                        games.forEachIndexed{idx,m->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if(chosen==idx)m.accent.copy(.18f)else panel).border(1.dp,if(chosen==idx)m.accent else Color.White.copy(.08f),RoundedCornerShape(16.dp)).clickable(enabled=!spinning){chosen=idx;reels=List(3){m.symbols.random()};note="Ты играешь в ${m.name}"}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                                Text(m.icon,fontSize=30.sp);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(m.name,color=Color.White,fontWeight=FontWeight.Black,fontSize=13.sp);Text("${m.subtitle} • ставка ${m.bet} монет",color=Color.LightGray,fontSize=10.sp)};Text(if(chosen==idx)"В ИГРЕ ✓" else "ИГРАТЬ ›",color=m.accent,fontSize=10.sp,fontWeight=FontWeight.Black)
                            }
                        }
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(25.dp)).background(Brush.verticalGradient(listOf(Color(0xFF32145B),Color(0xFF120A27)))).border(1.dp,game.accent.copy(.8f),RoundedCornerShape(25.dp)).padding(15.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(12.dp)){
                            Text("${game.icon}  ${game.name}  ${game.icon}",color=game.accent,fontWeight=FontWeight.Black,fontSize=18.sp,letterSpacing=1.sp)
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFF070411)).border(2.dp,game.accent.copy(.65f),RoundedCornerShape(18.dp)).padding(9.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                reels.forEachIndexed{idx,symbol->
                                    val inf= rememberInfiniteTransition(label="reel$idx")
                                    val shimmer by inf.animateFloat(initialValue=.75f,targetValue=1f,animationSpec=infiniteRepeatable(tween(650),RepeatMode.Reverse),label="glow")
                                    Box(Modifier.weight(1f).height(100.dp).scale(if(spinning)shimmer else 1f).clip(RoundedCornerShape(13.dp)).background(Brush.verticalGradient(listOf(Color(0xFFFFF7E5),Color(0xFFFFD98B),Color(0xFFFFF0C9)))),contentAlignment=Alignment.Center){Text(symbol,fontSize=38.sp)}
                                }
                            }
                            Text(note,color=if(lastWin>0)gold else Color.White,fontSize=13.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center,minLines=2)
                            NeonButton(if(spinning)"БАРАБАНЫ КРУТЯТСЯ..." else "КРУТИТЬ • ${game.bet} 🪙 ИЛИ 1 🎟",neon){spin()}
                            Text("3 одинаковых: до ${game.payout} монет • 2 одинаковых: ${game.bet*2} монет",color=Color.LightGray,fontSize=10.sp,textAlign=TextAlign.Center)
                        }
                    }
                }
                if(note.isNotBlank()) Text(note,color=gold,fontSize=11.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
                Text("DEMO ARCADE • БЕЗ РЕАЛЬНЫХ ДЕНЕГ • ВИРТУАЛЬНЫЕ МОНЕТЫ НЕ ИМЕЮТ ДЕНЕЖНОЙ ЦЕННОСТИ",color=Color(0xFF8F83A8),fontSize=9.sp,textAlign=TextAlign.Center,lineHeight=13.sp)
            }
        }
    }
}
@Composable private fun Header(title:String,subtitle:String){Column {Text(title,color=gold,fontSize=17.sp,fontWeight=FontWeight.Black,letterSpacing=1.5.sp);Text(subtitle,color=Color.LightGray,fontSize=11.sp)}}
@Composable private fun Stat(icon:String,title:String,value:String,modifier:Modifier){Column(modifier.clip(RoundedCornerShape(15.dp)).background(panel).border(1.dp,purple.copy(.5f),RoundedCornerShape(15.dp)).padding(vertical=10.dp,horizontal=4.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(icon,fontSize=17.sp);Text(title,color=Color.LightGray,fontSize=8.sp,fontWeight=FontWeight.Bold);Text(value,color=gold,fontSize=18.sp,fontWeight=FontWeight.Black)}}
@Composable private fun NavChip(label:String,active:Boolean,modifier:Modifier,onClick:()->Unit){Surface(modifier.clickable{onClick()},shape=RoundedCornerShape(13.dp),color=if(active)purple else panel,border=BorderStroke(1.dp,if(active)neon else Color.White.copy(.1f))){Text(label,Modifier.padding(vertical=12.dp),color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Black,textAlign=TextAlign.Center)}}
@Composable private fun NeonButton(label:String,color:Color,onClick:()->Unit){Button(onClick=onClick,modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=color,contentColor=Color(0xFF160A25))){Text(label,fontWeight=FontWeight.Black,fontSize=12.sp,textAlign=TextAlign.Center)}}
@Composable private fun ShopCard(title:String,price:String,icon:String,onBuy:()->Unit){Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(panel).border(1.dp,purple.copy(.5f),RoundedCornerShape(16.dp)).padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=28.sp);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,color=Color.White,fontWeight=FontWeight.Black);Text(price,color=gold,fontSize=12.sp)};Button(onClick=onBuy,colors=ButtonDefaults.buttonColors(containerColor=neon,contentColor=bg)){Text("КУПИТЬ",fontWeight=FontWeight.Black,fontSize=10.sp)} }}
