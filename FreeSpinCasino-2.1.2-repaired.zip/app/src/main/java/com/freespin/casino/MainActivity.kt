package com.freespin.casino

import android.os.Bundle
import androidx.compose.ui.platform.LocalConfiguration
import android.os.Vibrator
import android.os.VibrationEffect
import android.app.DatePickerDialog
import android.media.AudioManager
import android.media.ToneGenerator
import android.graphics.BitmapFactory
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.layout.ContentScale
import java.util.Calendar
import org.json.JSONArray
import org.json.JSONObject

private data class Machine(val name:String,val icon:String,val symbols:List<String>,val bg:Long,val accent:Long)
private val machines=listOf(
 Machine("STARLIGHT 777","🌌",listOf("⭐","🪐","💎","☄️","🌙","🔮"),0xFF24134D,0xFFD8B5FF),
 Machine("FRUIT NEON","🍒",listOf("🍒","🍋","🍉","🍇","🍊","🍓"),0xFF50142F,0xFFFF89B5),
 Machine("CYBER SPIN","🤖",listOf("🤖","⚡","💾","🚀","🔋","💠"),0xFF073641,0xFF55F5FF),
 Machine("GOLDEN EGYPT","🏺",listOf("🏺","🐈","☀️","💎","🪲","👑"),0xFF493014,0xFFFFDA78),
 Machine("PIRATE GOLD","🏴‍☠️",listOf("⚓","🦜","💰","💎","🗝️","🏴‍☠️"),0xFF153B39,0xFF8BE1C6),
 Machine("DRAGON FIRE","🐉",listOf("🐉","🔥","🥚","💎","🏯","☄️"),0xFF511C13,0xFFFFAB68))
private data class Match(val cells:List<Int>,val direction:Int)
private fun matches(grid:List<String>):List<Match>{
 val out=mutableListOf<Match>()
 val dirs=listOf(0 to 1,1 to 0,1 to 1,1 to -1)
 fun inside(r:Int,c:Int)=r in 0..3 && c in 0..4
 for((d,p) in dirs.withIndex()) for(r in 0..3) for(c in 0..4){
  val (dr,dc)=p; val s=grid[r*5+c]; val pr=r-dr;val pc=c-dc
  if(inside(pr,pc)&&grid[pr*5+pc]==s)continue
  val cells=mutableListOf<Int>();var y=r;var x=c
  while(inside(y,x)&&grid[y*5+x]==s){cells.add(y*5+x);y+=dr;x+=dc}
  if(cells.size>=3)out.add(Match(cells,d))
 }
 // Bent paths across adjacent reels, without duplicating straight matches.
 fun walk(path:List<Int>,lastStep:Int,bent:Boolean){
  val last=path.last();val col=last%5;val row=last/5
  val next=if(col==4) emptyList() else (-1..1).mapNotNull{step->val r=row+step;if(r in 0..3 && grid[r*5+col+1]==grid[last]) (r*5+col+1) to step else null}
  if(next.isEmpty() && bent && path.size>=3)out.add(Match(path,4))
  for((cell,step) in next)walk(path+cell,step,bent||(path.size>=2&&step!=lastStep))
 }
 for(r in 0..3)for(c in 0..2)walk(listOf(r*5+c),0,false)
 return out.distinctBy{it.cells}
}
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{Arcade()}}}
@Composable private fun Arcade(){
 val ctx=LocalContext.current;val wide=false;val prefs=remember{ctx.getSharedPreferences("casino_v3",0)};val scope=rememberCoroutineScope()
 var screen by remember{mutableStateOf("splash")};var name by remember{mutableStateOf(prefs.getString("name","Игрок")?:"Игрок")};var birth by remember{mutableStateOf(prefs.getString("birth","")?:"")}
 var coins by remember{mutableIntStateOf(prefs.getInt("coins",1500))};var tickets by remember{mutableIntStateOf(prefs.getInt("tickets",15))};var sound by remember{mutableStateOf(prefs.getBoolean("sound",true))};var volume by remember{mutableFloatStateOf(prefs.getFloat("volume",0.8f))};var anim by remember{mutableStateOf(prefs.getBoolean("anim",true))}
 var photo by remember{mutableStateOf(prefs.getString("photo","")?:"")};var history by remember{mutableStateOf(prefs.getString("history","[]")?:"[]")};var won by remember{mutableIntStateOf(prefs.getInt("winCount",0))};var lost by remember{mutableIntStateOf(prefs.getInt("lossCount",0))};var biggest by remember{mutableIntStateOf(prefs.getInt("biggest",0))}
 var draft by remember { mutableStateOf(name) }; var profileStatus by remember { mutableStateOf("") }; var saving by remember { mutableStateOf(false) }; var draftPhoto by remember { mutableStateOf(photo) }; val reelOffsets = remember { List(5) { Animatable(0f) } }; var reelStrips by remember { mutableStateOf(List(5){ emptyList<String>() }) }; val cellPx = with(LocalDensity.current){ 64.dp.toPx() }
 var dice by remember{mutableStateOf(listOf(1,1))};var roulette by remember{mutableIntStateOf(0)};var rouletteHistory by remember{mutableStateOf(emptyList<Int>())};val wheelAngle=remember{Animatable(0f)};var music by remember{mutableStateOf(prefs.getBoolean("music",true))};var musicVolume by remember{mutableFloatStateOf(prefs.getFloat("musicVolume",0.4f))};var vibration by remember{mutableStateOf(prefs.getBoolean("vibration",true))};var selected by remember{mutableIntStateOf(0)};val game=machines[selected];var bet by remember{mutableIntStateOf(25)};var grid by remember{mutableStateOf(List(20){machines[0].symbols.random()})};var lines by remember{mutableStateOf(emptyList<Match>())};var busy by remember{mutableStateOf(false)};var msg by remember{mutableStateOf("")}
 val effects: android.media.SoundPool = remember { android.media.SoundPool.Builder().setMaxStreams(4).setAudioAttributes(android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_GAME).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build() }
 val loaded=remember { mutableSetOf<Int>() }
 val ids=remember { effects.setOnLoadCompleteListener { _, id, status -> if(status==0) loaded.add(id) }; listOf(R.raw.sfx_07bd310ad4650d5,R.raw.sfx_7a6d49008a3f82355,R.raw.sfx_fruit_machine_jackpot_001_long,R.raw.sfx_slot_machine_win_jackpot_04,R.raw.sfx_casino_coin_movement_1,R.raw.sfx_442234_slot_machine_1,R.raw.sfx_slot_machine_win_coins_falling_into_pay_out_slot_a_1).map{effects.load(ctx,it,1)} }
 DisposableEffect(effects){onDispose{effects.release()}}
 fun effect(index:Int):Int { val id=ids[index];return if(sound&&id in loaded) effects.play(id,volume,volume,1,0,1f) else 0 }
 fun play(t:Int,ms:Int=100){effect(when(t){ToneGenerator.TONE_PROP_BEEP->0;ToneGenerator.TONE_PROP_NACK->1;ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD->3;else->2});if(vibration)runCatching{val v=ctx.getSystemService(android.content.Context.VIBRATOR_SERVICE) as Vibrator;if(android.os.Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(35,VibrationEffect.DEFAULT_AMPLITUDE)) else v.vibrate(35)}}
 val player=remember(screen,selected,music){if(music&&screen in listOf("home","game","roulette","dice"))runCatching{val id=ctx.resources.getIdentifier("theme_"+(if(screen=="game")selected+1 else if(screen=="roulette")7 else if(screen=="dice")8 else 0),"raw",ctx.packageName);android.media.MediaPlayer.create(ctx,id)?.apply{isLooping=true;setVolume(musicVolume,musicVolume);start()}}.getOrNull() else null};DisposableEffect(player){onDispose{player?.release()}};LaunchedEffect(player,musicVolume){player?.setVolume(musicVolume,musicVolume)}
 fun save(){prefs.edit().putBoolean("music",music).putFloat("musicVolume",musicVolume).putBoolean("vibration",vibration).putString("name",name).putString("birth",birth).putString("photo",photo).putInt("coins",coins).putInt("tickets",tickets).putBoolean("sound",sound).putFloat("volume",volume).putBoolean("anim",anim).putString("history",history).putInt("winCount",won).putInt("lossCount",lost).putInt("biggest",biggest).apply()}
 fun adult(date:String):Boolean=runCatching{val p=date.split("-").map{it.toInt()};val b=Calendar.getInstance().apply{clear();isLenient=false;set(p[0],p[1]-1,p[2])};val limit=Calendar.getInstance().apply{add(Calendar.YEAR,-18)};b.timeInMillis<=limit.timeInMillis && p[0]>=1900}.getOrDefault(false)
 fun datePick(){val now=Calendar.getInstance();DatePickerDialog(ctx,{_,y,m,d->birth="%04d-%02d-%02d".format(java.util.Locale.US,y,m+1,d);save();if(!adult(birth))screen="age"},now.get(Calendar.YEAR)-18,now.get(Calendar.MONTH),now.get(Calendar.DAY_OF_MONTH)).apply{datePicker.maxDate=now.timeInMillis}.show()}
 val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null){runCatching{ctx.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);draftPhoto=uri.toString()}}}
 fun go(s:String){if(!busy&&!saving){play(ToneGenerator.TONE_PROP_BEEP,60);if(s=="profile"){draft=name;draftPhoto=photo;profileStatus=""};screen=s;msg=""}}
 LaunchedEffect(Unit){delay(if(anim)1600 else 200);screen=if(adult(birth))"home" else "age"}
 BackHandler(screen!="home"&&screen!="age"&&screen!="splash"){go("home")}
 fun spin(ticket:Boolean){if(busy)return;if((ticket&&tickets<=0)||(!ticket&&coins<bet)){msg="Недостаточно средств";return};busy=true;lines=emptyList();val stake=bet
 scope.launch{val result=List(20){game.symbols.random()};if(anim){val spinSound=effect(5);reelStrips=List(5){c->List(4){r->grid[r*5+c]}+List(16){game.symbols.random()}+List(4){r->result[r*5+c]}};kotlinx.coroutines.coroutineScope { for(c in 0..4) launch { reelOffsets[c].snapTo(0f);reelOffsets[c].animateTo(20f*cellPx,tween(950+c*180,easing=LinearOutSlowInEasing));effect(0) } };if(spinSound!=0)effects.stop(spinSound)};grid=result;lines=matches(grid);val payout=lines.sumOf{stake*(it.cells.size-2)}* 27 / 100;if(ticket)tickets-- else coins-=stake;coins+=payout;val net=payout-(if(ticket)0 else stake);if(payout>0){effect(6);won++;biggest=maxOf(biggest,payout);play(if(payout>=stake*12)ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD else ToneGenerator.TONE_PROP_ACK,450)}else{lost++;play(ToneGenerator.TONE_PROP_NACK,220)};msg=if(payout>0)"Совпадений: ${lines.size} • +$payout монет" else "Нет совпадений";val old=JSONArray(history);val arr=JSONArray().put(JSONObject().put("game",game.name).put("time",System.currentTimeMillis()).put("bet",stake).put("ticket",ticket).put("payout",payout).put("net",net));for(i in 0 until minOf(old.length(),499))arr.put(old.getJSONObject(i));history=arr.toString();save();busy=false}}
 fun recordExtra(label:String,stake:Int,payout:Int){coins+=payout;if(payout>0){won++;biggest=maxOf(biggest,payout)}else lost++;val old=JSONArray(history);val arr=JSONArray().put(JSONObject().put("game",label).put("time",System.currentTimeMillis()).put("bet",stake).put("payout",payout).put("net",payout-stake));for(i in 0 until minOf(old.length(),499))arr.put(old.getJSONObject(i));history=arr.toString();save()}
 val accent=if(screen=="game")Color(game.accent)else Color(0xFFFFDA78);val bg=if(screen=="game")Color(game.bg)else Color(0xFF190D2B)
 MaterialTheme(colorScheme=darkColorScheme(primary=accent,background=bg,surface=bg,onBackground=Color.White,onSurface=Color.White,onSurfaceVariant=Color.LightGray)){
 CompositionLocalProvider(LocalContentColor provides Color.White) {
 Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bg,Color(0xFF080414)))).systemBarsPadding().verticalScroll(rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 if(screen=="splash"){val transition=rememberInfiniteTransition(label="splash");val scale by transition.animateFloat(.8f,1.1f,infiniteRepeatable(tween(500),RepeatMode.Reverse),label="logo");Box(Modifier.fillMaxWidth().height(450.dp),contentAlignment=Alignment.Center){Text("✦ FREE SPIN ✦\n3.1.3 ARCADE",Modifier.scale(if(anim)scale else 1f),color=accent,fontSize=32.sp,fontWeight=FontWeight.Black)}}else if(screen=="age"){
 Text("FREE SPIN • 18+",fontSize=30.sp,color=accent);Text("Введите дату рождения. Только для взрослых. Дата вводится самостоятельно.");Button(onClick={datePick()}){Text(birth.ifEmpty{"Выбрать дату рождения"})};if(birth.isNotEmpty()&&!adult(birth))Text("Доступ только с 18 лет",color=Color.Red);Button(onClick={save();go("home")},enabled=adult(birth)){Text("Продолжить")}
 }else{
 Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){if(screen=="home")TextButton(onClick={go("profile")}){Row(verticalAlignment=Alignment.CenterVertically){ProfileAvatar(photo,32.dp);Spacer(Modifier.width(5.dp));Text(name.take(16))}}else TextButton(onClick={go("home")},enabled=!busy){Text("‹ Назад")};Text("🪙 $coins  🎟 $tickets",color=accent);if(screen=="home")TextButton(onClick={go("settings")}){Text("⚙")}}
 when(screen){
 "home"->{Text("FREE SPIN • 3.1.3",fontSize=28.sp,fontWeight=FontWeight.Black,color=accent);Text("Выбери автомат");for(pair in machines.chunked(if(wide)3 else 2)){Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){for(m in pair){Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(Color(m.bg)).border(1.dp,Color(m.accent),RoundedCornerShape(18.dp)).clickable{selected=machines.indexOf(m);grid=List(20){m.symbols.random()};lines=emptyList();go("game")}.padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally){SlotArt(m.symbols.first(),Modifier.size(52.dp));Text(m.name,color=Color(m.accent),fontWeight=FontWeight.Bold);Text("ИГРАТЬ")}}}};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){Button(onClick={go("roulette")}){Text("Рулетка")};Button(onClick={go("dice")}){Text("Кости")}};Row{TextButton(onClick={go("shop")}){Text("🛍 Магазин")};TextButton(onClick={go("bonus")}){Text("🎁 Бонусы")}}}
 "game"->{Text(game.name,color=accent,fontSize=25.sp,fontWeight=FontWeight.Black);Box(Modifier.fillMaxWidth().height(256.dp).background(bg,RoundedCornerShape(12.dp))){Row(Modifier.fillMaxSize(),horizontalArrangement=Arrangement.spacedBy(4.dp)){for(c in 0..4){Box(Modifier.weight(1f).fillMaxHeight().clipToBounds().border(1.dp,accent,RoundedCornerShape(8.dp))){Column(Modifier.offset { androidx.compose.ui.unit.IntOffset(0,if(busy&&anim&&reelStrips[c].isNotEmpty()) -reelOffsets[c].value.toInt() else 0) }.wrapContentHeight(Alignment.Top,unbounded=true)){val symbols=if(busy&&anim&&reelStrips[c].isNotEmpty())reelStrips[c] else List(4){r->grid[r*5+c]};for((r,symbol) in symbols.withIndex()){Box(Modifier.fillMaxWidth().height(64.dp).padding(2.dp).background(Brush.verticalGradient(listOf(Color(0xFF171321),accent.copy(alpha=if(!busy&&lines.any{r*5+c in it.cells}) .8f else .35f),Color(0xFF171321))),RoundedCornerShape(8.dp)),contentAlignment=Alignment.Center){Box(Modifier.size(44.dp).background(Brush.radialGradient(listOf(accent.copy(alpha=.65f),Color(0xFF191323))),RoundedCornerShape(14.dp)).border(1.dp,accent.copy(alpha=.65f),RoundedCornerShape(14.dp)),contentAlignment=Alignment.Center){SlotArt(symbol,Modifier.fillMaxSize().padding(3.dp))}}}}}}};Canvas(Modifier.matchParentSize()){val gap=4.dp.toPx();val w=(size.width-4*gap)/5;val h=size.height/4;for(l in lines){val color=listOf(Color.Yellow,Color.Cyan,Color.Magenta,Color.Green,Color(0xFFFF9040))[l.direction];for((a,b) in l.cells.zipWithNext()){val start=Offset((a%5)*(w+gap)+w/2,(a/5+.5f)*h);val end=Offset((b%5)*(w+gap)+w/2,(b/5+.5f)*h);drawLine(Color.Black,start,end,strokeWidth=6.dp.toPx());drawLine(color,start,end,strokeWidth=3.dp.toPx())}}}};Text("3+ одинаковых подряд • прямые и ломаные линии • выплата: 27% ставки за каждый символ сверх двух, округление общей суммы вниз");Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){Button(onClick={bet=(bet-5).coerceAtLeast(5)},enabled=!busy){Text("−")};Text("Ставка $bet",color=accent,fontSize=20.sp);Button(onClick={bet=(bet+5).coerceAtMost(100)},enabled=!busy){Text("+")}};Button(onClick={spin(false)},enabled=!busy&&coins>=bet,modifier=Modifier.fillMaxWidth()){Text(if(busy)"Вращение…" else "КРУТИТЬ • $bet 🪙")};OutlinedButton(onClick={spin(true)},enabled=!busy&&tickets>0,modifier=Modifier.fillMaxWidth()){Text("Вращение за билет")};Text(msg,color=accent)}
 "roulette"->{Text("ЕВРОПЕЙСКАЯ РУЛЕТКА",fontSize=24.sp,color=accent);Box(Modifier.fillMaxWidth(),contentAlignment=Alignment.Center){Canvas(Modifier.size(290.dp).rotate(wheelAngle.value)){val step=360f/37f;drawCircle(Color(0xFFB78A43));for((i,n) in wheelNumbers.withIndex()){drawArc(wheelColor(n),-90f-step/2+i*step,step-.35f,true,topLeft=Offset(size.width*.035f,size.height*.035f),size=androidx.compose.ui.geometry.Size(size.width*.93f,size.height*.93f));val angle=Math.toRadians((-90+i*step).toDouble());val paint=android.graphics.Paint(3).apply{color=android.graphics.Color.WHITE;textSize=size.width*.033f;textAlign=android.graphics.Paint.Align.CENTER;typeface=android.graphics.Typeface.DEFAULT_BOLD};drawContext.canvas.nativeCanvas.drawText(n.toString(),center.x+(kotlin.math.cos(angle)*size.width*.405).toFloat(),center.y+(kotlin.math.sin(angle)*size.width*.405).toFloat()+paint.textSize*.35f,paint)};drawCircle(Color(0xFFB78A43),size.width*.34f);drawCircle(Color(0xFF214A37),size.width*.32f);drawCircle(Color(0xFFB78A43),size.width*.10f)};Canvas(Modifier.size(290.dp)){drawCircle(Color.White,5.dp.toPx(),Offset(center.x,size.height*.095f));drawCircle(Color.LightGray,2.dp.toPx(),Offset(center.x-1.dp.toPx(),size.height*.095f-1.dp.toPx()))};Text(if(busy)"…" else roulette.toString(),fontSize=32.sp,color=Color.White)};Text("Результат: $roulette",color=wheelColor(roulette).let{if(roulette in redNumbers)Color(0xFFFF7777) else if(roulette==0)Color.Green else Color.White});Button(enabled=!busy,onClick={busy=true;scope.launch{val n=(0..36).random();val target=(360f-wheelNumbers.indexOf(n)*360f/37f)%360f;val delta=(target-wheelAngle.value%360f+360f)%360f;val stream=effect(5);if(anim)wheelAngle.animateTo(wheelAngle.value+1080f+delta,tween(2400,easing=LinearOutSlowInEasing));wheelAngle.snapTo(target);if(stream!=0)effects.stop(stream);roulette=n;rouletteHistory=(listOf(n)+rouletteHistory).take(12);busy=false;play(ToneGenerator.TONE_PROP_ACK)}}){Text("Вращать колесо")};Text("Последние результаты: "+rouletteHistory.joinToString(" • "));Text("Свободная игра без ставок")}
 "dice"->{Text("ИГРОВЫЕ КОСТИ",fontSize=24.sp,color=accent);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center){for(n in dice){Box(Modifier.padding(8.dp).size(100.dp).background(Brush.linearGradient(listOf(Color.White,Color(0xFFB8B8C8))),RoundedCornerShape(16.dp)).border(2.dp,Color.White,RoundedCornerShape(16.dp)),contentAlignment=Alignment.Center){Canvas(Modifier.fillMaxSize().padding(12.dp)){val positions=when(n){1->listOf(4);2->listOf(0,8);3->listOf(0,4,8);4->listOf(0,2,6,8);5->listOf(0,2,4,6,8);else->listOf(0,2,3,5,6,8)};for(i in positions)drawCircle(Color(0xFF24202C),size.minDimension*.085f,Offset(size.width*(.2f+.3f*(i%3)),size.height*(.2f+.3f*(i/3))))}}}};Text("Сумма: ${dice.sum()}",fontSize=24.sp);Button(enabled=!busy,onClick={busy=true;scope.launch{if(anim)repeat(12){dice=List(2){(1..6).random()};delay(65)};dice=List(2){(1..6).random()};play(ToneGenerator.TONE_PROP_ACK);busy=false}}){Text("Бросить кости")};Text("Свободная игра без ставок")}
 "profile"->{Text("МОЙ АККАУНТ",fontSize=24.sp,color=accent);ProfileAvatar(draftPhoto,100.dp);Button(onClick={picker.launch(arrayOf("image/*"))},enabled=!saving){Text("Выбрать фото")};OutlinedTextField(draft,{draft=it.take(24);profileStatus=""},label={Text("Имя")},enabled=!saving);Text("3–24 русские или английские буквы, цифры или _");Button(enabled=!saving,onClick={val candidate=draft.trim().lowercase(java.util.Locale.ROOT);if(!candidate.matches(Regex("^[a-zа-яё0-9_]{3,24}$"))){profileStatus="Недопустимое имя"}else{saving=true;scope.launch{try{val auth=FirebaseAuth.getInstance();val uid=(auth.currentUser?:auth.signInAnonymously().await().user?:error("auth")).uid;val db=FirebaseFirestore.getInstance();val ref=db.collection("usernames").document(candidate);val old=prefs.getString("reservedName","").orEmpty();val ok=db.runTransaction{tx->val doc=tx.get(ref);if(doc.exists()&&doc.getString("uid")!=uid)false else {val previous=if(old.isNotEmpty()&&old!=candidate)db.collection("usernames").document(old) else null;val previousDoc=previous?.let{tx.get(it)};if(!doc.exists())tx.set(ref,mapOf("uid" to uid));if(previous!=null&&previousDoc?.getString("uid")==uid)tx.delete(previous);true}}.await();if(ok){name=draft.trim();photo=draftPhoto;prefs.edit().putString("reservedName",candidate).apply();save();profileStatus="Имя доступно. Профиль успешно сохранён"}else profileStatus="Имя уже занято"}catch(e:Exception){profileStatus="Не удалось проверить имя. Проверьте интернет."}finally{saving=false}}}}){Text(if(saving)"Проверка…" else "Сохранить")};Text(profileStatus,color=if(profileStatus.startsWith("Имя доступно")) Color(0xFF72E69A) else Color(0xFFFF8585));Button(onClick={datePick()}){Text("Дата рождения: $birth")};Text("Выигрышей: $won • проигрышей: $lost");Text("Всего: ${won+lost} • крупнейший выигрыш: $biggest");Text("История игр",fontSize=22.sp);val arr=JSONArray(history);for(i in 0 until arr.length()){val h=arr.getJSONObject(i);Text(h.getString("game")+" • "+java.text.DateFormat.getDateTimeInstance().format(java.util.Date(h.getLong("time")))+"\nСтавка: "+h.getInt("bet")+ (if(h.optBoolean("ticket"))" (билет)" else " монет")+" • Выплата: "+h.getInt("payout")+" • Итог: "+h.getInt("net"));HorizontalDivider()}}
 "settings"->{Text("НАСТРОЙКИ",fontSize=24.sp,color=accent);Row(verticalAlignment=Alignment.CenterVertically){Text("Звуковые эффекты",Modifier.weight(1f));Switch(sound,{sound=it;save()})};Text("Громкость ${(volume*100).toInt()}%");Slider(volume,{volume=it;save()});Row(verticalAlignment=Alignment.CenterVertically){Text("Анимации",Modifier.weight(1f));Switch(anim,{anim=it;save()})};Row(verticalAlignment=Alignment.CenterVertically){Text("Музыка",Modifier.weight(1f));Switch(music,{music=it;save()})};Text("Громкость музыки ${(musicVolume*100).toInt()}%");Slider(musicVolume,{musicVolume=it;save()});Row(verticalAlignment=Alignment.CenterVertically){Text("Вибрация",Modifier.weight(1f));Switch(vibration,{vibration=it;save()})};Button(onClick={save();msg="Настройки сохранены"}){Text("Сохранить")};Text(msg);Button(onClick={ctx.startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://github.com/GRESHNYY-ZM/FreeSpinCasino/releases")))}){Text("Проверить обновления")};Text("Русский • 3.1.3 Arcade\nДанные хранятся на устройстве. Реальные деньги не используются.")}
 "shop"->{Text("Магазин виртуальных билетов",fontSize=22.sp);for((n,c) in listOf(5 to 125,12 to 250,30 to 500)){Button(onClick={coins-=c;tickets+=n;save()},enabled=coins>=c){Text("$n билетов за $c монет")}}}
 "bonus"->{Text("Ежедневный бонус",fontSize=24.sp);val rewards=listOf("100 монет","200 монет","2 билета","400 монет","600 монет","5 билетов","1000 монет + 10 билетов");val next=prefs.getInt("rewardIndex",0)%7;for(group in rewards.withIndex().toList().chunked(2)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){for((i,reward) in group){Column(Modifier.weight(1f).background(if(i==next)accent.copy(alpha=.25f) else Color(0xFF302440),RoundedCornerShape(12.dp)).border(1.dp,if(i==next)accent else Color.Gray,RoundedCornerShape(12.dp)).padding(12.dp)){Text("День ${i+1}",color=accent,fontWeight=FontWeight.Bold);Text(reward);Text(if(i<next)"Получено" else if(i==next)"Следующая" else "Ожидает",fontSize=12.sp)}}}};val day=java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(java.util.Date());var claimed by remember{mutableStateOf(prefs.getString("daily","")==day)};Button(onClick={val index=prefs.getInt("rewardIndex",0)%7;coins+=listOf(100,200,0,400,600,0,1000)[index];tickets+=listOf(0,0,2,0,0,5,10)[index];claimed=true;effect(4);prefs.edit().putString("daily",day).putInt("rewardIndex",index+1).apply();save()},enabled=!claimed){Text(if(claimed)"Получено сегодня" else "Получить награду дня ${prefs.getInt("rewardIndex",0)%7+1}")}}
 };Text("18+ • Только виртуальные монеты • Без денежных ставок",color=Color.LightGray,fontSize=11.sp)
 }
 }}
}
}

@Composable private fun ProfileAvatar(photo:String,size:Dp){val ctx=LocalContext.current;val bitmap=remember(photo){if(photo.isBlank())null else runCatching{ctx.contentResolver.openInputStream(android.net.Uri.parse(photo))?.use{BitmapFactory.decodeStream(it)}}.getOrNull()};if(bitmap!=null)Image(bitmap.asImageBitmap(),"Фото профиля",Modifier.size(size).clip(RoundedCornerShape(50)),contentScale=ContentScale.Crop)else Text("👤",fontSize=(size.value*.6f).sp)}

private val wheelNumbers=listOf(0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26)
private val redNumbers=setOf(1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36)
private fun wheelColor(n:Int)=if(n==0)Color(0xFF168044) else if(n in redNumbers)Color(0xFFAA2020) else Color(0xFF171717)
@Composable private fun SlotArt(symbol:String,modifier:Modifier=Modifier){
 val ctx=LocalContext.current
 val index=machines.flatMap{it.symbols}.distinct().indexOf(symbol)
 val id=remember(index){ctx.resources.getIdentifier("symbol_"+index,"drawable",ctx.packageName)}
 if(id!=0)Image(androidx.compose.ui.res.painterResource(id),symbol,modifier,contentScale=ContentScale.Fit)
}
