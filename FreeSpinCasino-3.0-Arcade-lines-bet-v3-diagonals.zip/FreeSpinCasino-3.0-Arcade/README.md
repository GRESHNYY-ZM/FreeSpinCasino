# FreeSpinCasino 3.0 — Neon Arcade
Android Kotlin + Jetpack Compose project. Main screen contains five separate arcade cabinets; selecting one navigates to its own game screen. Includes animated splash, custom launcher icon, original generated sound effects, virtual coins/tickets and daily bonus.

Build with GitHub Actions workflow `.github/workflows/build-apk.yml`. Upload this source ZIP to the repository root and run Actions. No real-money betting, deposits or cash-outs.
