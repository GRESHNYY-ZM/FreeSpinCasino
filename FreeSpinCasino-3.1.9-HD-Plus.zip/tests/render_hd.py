from PIL import Image, ImageFilter
import numpy as np
from pathlib import Path
# Re-light original artwork with a bevel derived from its silhouette and internal color edges.
root=Path(__file__).resolve().parents[1]/'app/src/main/res/drawable'
for p in sorted(root.glob('symbol_*.png')):
 im=Image.open(p).convert('RGBA').resize((512,512),Image.Resampling.LANCZOS)
 a=np.asarray(im).astype(float)/255; rgb=a[:,:,:3]; alpha=a[:,:,3]
 def blur(v,r): return np.asarray(Image.fromarray(np.uint8(np.clip(v,0,1)*255)).filter(ImageFilter.GaussianBlur(r))).astype(float)/255
 lum=rgb@np.array([.299,.587,.114]); h=blur(alpha,12)*.75+blur(lum*alpha,6)*.25
 dy,dx=np.gradient(h); nx=-dx*25; ny=-dy*25; nz=1/np.sqrt(1+nx*nx+ny*ny); nx*=nz;ny*=nz
 light=np.clip(-.45*nx-.55*ny+.70*nz,0,1)
 y,x=np.mgrid[0:512,0:512]; gloss=np.exp(-((x-170)/145)**2-((y-125)/85)**2)*.20
 spec=np.maximum(0,(-.28*nx-.38*ny+.88*nz))**22*.26
 out=np.clip(rgb*(.70+.48*light[:,:,None])+ (gloss+spec)[:,:,None]*(1-rgb*.55),0,1)
 edge=np.clip(alpha-blur(alpha,3),0,1);out=np.clip(out+edge[:,:,None]*.22,0,1)
 result=np.dstack([out,alpha]);Image.fromarray(np.uint8(result*255),'RGBA').save(p,optimize=True)
