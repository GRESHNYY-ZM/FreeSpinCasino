package com.freespin.casino
fun main(){for(n in 0..36)check((0..36).sumOf{roulettePayout(it,n,0,25)}==900);for(c in 1..2){check((0..36).sumOf{roulettePayout(it,null,c,25)}==900);check(roulettePayout(0,null,c,25)==0)};for(p in 0..1)check((1..6).sumOf{a->(1..6).sumOf{b->dicePayout(a+b,p,25)}}==900);check(roulettePayout(1,1,1,25)==950);println("All payout checks passed")}
