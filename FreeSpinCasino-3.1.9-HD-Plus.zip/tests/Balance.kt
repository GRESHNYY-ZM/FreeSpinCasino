private data class Match(val cells:List<Int>,val direction:Int)
private fun matches(grid:List<String>):List<Match>{
 val out=mutableListOf<Match>()
 val dirs=listOf(0 to 1,1 to 0,1 to 1,1 to -1)
 fun inside(r:Int,c:Int)=r in 0..3 && c in 0..4
 for((d,p) in dirs.withIndex()) for(r in 0..3) for(c in 0..4){
  val (dr,dc)=p; val s=grid[r*5+c]; val pr=r-dr;val pc=c-dc
  if(inside(pr,pc)&&grid[pr*5+pc]==s)continue
  val cells=mutableListOf<Int>();var y=r;var x=c
  while(inside(y,x)&&grid[y*5+x]==s){cells.add(y*5+x);y+=dr;x+=dc}
  if(cells.size>=3)out.add(Match(cells,d))
 }
 // Bent paths across adjacent reels, without duplicating straight matches.
 fun walk(path:List<Int>,lastStep:Int,bent:Boolean){
  val last=path.last();val col=last%5;val row=last/5
  val next=if(col==4) emptyList() else (-1..1).mapNotNull{step->val r=row+step;if(r in 0..3 && grid[r*5+col+1]==grid[last]) (r*5+col+1) to step else null}
  if(next.isEmpty() && bent && path.size>=3)out.add(Match(path,4))
  for((cell,step) in next)walk(path+cell,step,bent||(path.size>=2&&step!=lastStep))
 }
 for(r in 0..3)for(c in 0..2)walk(listOf(r*5+c),0,false)
 return out.distinctBy{it.cells}
}
fun main(){val rng=kotlin.random.Random(313);val bets=(5..100 step 5).toList();val totals=LongArray(bets.size);val n=200000;repeat(n){val grid=List(20){rng.nextInt(6).toString()};val units=matches(grid).sumOf{it.cells.size-2};for(i in bets.indices)totals[i]+=(bets[i]*units*27/100).toLong()};for(i in bets.indices)println("${bets[i]} ${100.0*totals[i]/n/bets[i]}") }