package com.freespin.casino
private val reds=setOf(1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36)
internal fun roulettePayout(result:Int,number:Int?,color:Int,stake:Int):Int = (if(number==result)36*stake else 0)+(if((color==1&&result in reds)||(color==2&&result!=0&&result !in reds))2*stake else 0)
internal fun dicePayout(sum:Int,parity:Int,stake:Int):Int=if(sum%2==parity)2*stake else 0
